using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class RaceManager : MonoBehaviour
{
    public static RaceManager Instance { get; private set; }
    private List<Transform> waypoints = new List<Transform>();
    private List<RacerController> racers = new List<RacerController>();
    private List<RankingEntry> finalRankings = new List<RankingEntry>();
    private int finishedCount = 0;
    public bool RaceActive { get; private set; }
    public List<RacerController> Racers => racers;

    public struct RankingEntry
    {
        public int racerIndex; public string racerName; public Color racerColor; public int rank;
    }

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    private void Start()
    {
        GenerateTrack(); SpawnRacers();
        if (GameManager.Instance != null) GameManager.Instance.OnRaceStart += StartRace;
    }

    private void OnDestroy()
    {
        if (GameManager.Instance != null) GameManager.Instance.OnRaceStart -= StartRace;
    }

    public void GenerateTrack()
    {
        // 트랙 중심 = (2, 0, 0) TrackVisualizer와 동일
        Vector3 trackCenter = new Vector3(2f, 0, 0);

        GameObject p = new GameObject("Waypoints");
        p.transform.SetParent(transform);
        p.transform.position = trackCenter;
        waypoints.Clear();

        for (int i = 0; i < GameConstants.WAYPOINT_COUNT; i++)
        {
            float a = i * (360f / GameConstants.WAYPOINT_COUNT) * Mathf.Deg2Rad;
            GameObject wp = new GameObject("WP_" + i);
            wp.transform.SetParent(p.transform);
            wp.transform.localPosition = new Vector3(
                GameConstants.TRACK_RADIUS_X * Mathf.Sin(a),
                GameConstants.TRACK_RADIUS_Y * Mathf.Cos(a), 0);
            waypoints.Add(wp.transform);
        }
    }

    private void SpawnRacers()
    {
        GameObject p = new GameObject("Racers");
        p.transform.SetParent(transform);
        for (int i = 0; i < GameConstants.RACER_COUNT; i++)
        {
            GameObject obj = MakeRacer(i);
            obj.transform.SetParent(p.transform);
            obj.name = "Racer_" + GameConstants.RACER_NAMES[i];
            RacerController c = obj.AddComponent<RacerController>();
            c.Initialize(i, waypoints);

            // 출발선 근처에 살짝 퍼뜨려 배치
            float offsetY = (i - GameConstants.RACER_COUNT / 2f) * 0.18f;
            obj.transform.position = waypoints[0].position + new Vector3(-0.3f, offsetY, 0);
            racers.Add(c);
        }
    }

    private GameObject MakeRacer(int i)
    {
        GameObject obj = new GameObject();
        SpriteRenderer sr = obj.AddComponent<SpriteRenderer>();
        sr.sprite = MakeCircle();
        sr.color = GameConstants.RACER_COLORS[i];
        sr.sortingOrder = 10 + i;
        obj.transform.localScale = new Vector3(0.45f, 0.45f, 1f);

        GameObject lb = new GameObject("Label");
        lb.transform.SetParent(obj.transform);
        lb.transform.localPosition = Vector3.zero;
        lb.transform.localScale = Vector3.one;
        TextMesh tm = lb.AddComponent<TextMesh>();
        tm.text = (i + 1).ToString();
        tm.alignment = TextAlignment.Center;
        tm.anchor = TextAnchor.MiddleCenter;
        tm.characterSize = 0.25f;
        tm.fontSize = 48;
        tm.fontStyle = FontStyle.Bold;
        Color c = GameConstants.RACER_COLORS[i];
        tm.color = (c.r * 0.299f + c.g * 0.587f + c.b * 0.114f) > 0.5f ? Color.black : Color.white;
        lb.GetComponent<MeshRenderer>().sortingOrder = 11 + i;
        return obj;
    }

    private Sprite MakeCircle()
    {
        int s = 64; Texture2D t = new Texture2D(s, s, TextureFormat.RGBA32, false);
        float r = s / 2f;
        for (int x = 0; x < s; x++)
            for (int y = 0; y < s; y++)
            {
                float d = Vector2.Distance(new Vector2(x, y), new Vector2(r, r));
                t.SetPixel(x, y, d < r - 1 ? Color.white : d < r ? new Color(1, 1, 1, 0.5f) : Color.clear);
            }
        t.Apply(); t.filterMode = FilterMode.Bilinear;
        return Sprite.Create(t, new Rect(0, 0, s, s), new Vector2(0.5f, 0.5f), 64f);
    }

    public void StartRace()
    {
        RaceActive = true; finishedCount = 0; finalRankings.Clear();
        foreach (var r in racers) { r.StartRacing(); r.OnFinished += OnFinish; }
    }

    private void OnFinish(RacerController r)
    {
        finishedCount++; r.OnFinished -= OnFinish;
        finalRankings.Add(new RankingEntry {
            racerIndex = r.RacerIndex, racerName = GameConstants.RACER_NAMES[r.RacerIndex],
            racerColor = GameConstants.RACER_COLORS[r.RacerIndex], rank = finishedCount });
        if (finishedCount >= GameConstants.RACER_COUNT)
        {
            RaceActive = false;
            GameManager.Instance?.ChangeState(GameManager.GameState.Result);
        }
    }

    public List<RacerController> GetLiveRankings()
    {
        return racers.OrderByDescending(r => r.IsFinished ? 1000 : 0)
            .ThenByDescending(r => r.TotalProgress).ToList();
    }

    public List<RankingEntry> GetFinalRankings() => finalRankings;

    public void ResetRace()
    {
        RaceActive = false; finishedCount = 0; finalRankings.Clear();
        for (int i = 0; i < racers.Count; i++)
        {
            float offsetY = (i - GameConstants.RACER_COUNT / 2f) * 0.18f;
            racers[i].ResetRacer(waypoints[0].position + new Vector3(-0.3f, offsetY, 0));
        }
    }
}
