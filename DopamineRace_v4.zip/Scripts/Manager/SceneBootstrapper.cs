using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 와이어프레임 기반 레이아웃:
/// [왼쪽] 우승 선택 패널 (세로 리스트 12명)
/// [중앙] 레이스 경기장 (트랙 보임)
/// [우하단] Start 버튼
/// </summary>
public class SceneBootstrapper : MonoBehaviour
{
    private Font font;
    private int selectedFirst = -1;
    private int selectedSecond = -1;
    private bool selectingFirst = true; // true=1등 선택중, false=2등 선택중

    // UI 참조
    private Button[] racerButtons;
    private Text[] racerTexts;
    private Text[] racerLabels;
    private Image[] racerBGs;
    private Button startButton;
    private Text titleText;
    private Text infoText;
    private Text scoreText;

    // 레이스 중 UI
    private GameObject bettingUI;
    private GameObject racingUI;
    private GameObject resultUI;
    private GameObject countdownUI;
    private Text countdownText;
    private Text raceTimerText;
    private Text[] rankTexts;
    private Text myBetText;

    // 결과 UI
    private Text resultTitleText;
    private Text resultDetailText;
    private Text resultScoreText;
    private Button nextRoundButton;

    private float raceTimer;
    private float rankUpdateTimer;

    private void Awake()
    {
        if (GameManager.Instance != null) return;

        font = Font.CreateDynamicFontFromOSFont("Malgun Gothic", 24);
        if (font == null) font = Font.CreateDynamicFontFromOSFont("Arial", 24);

        // 매니저 생성
        new GameObject("GameManager").AddComponent<GameManager>();
        new GameObject("RaceManager").AddComponent<RaceManager>();
        new GameObject("ScoreManager").AddComponent<ScoreManager>();

        // 카메라 설정 (트랙이 오른쪽에 보이도록)
        Camera cam = Camera.main;
        if (cam != null)
        {
            cam.orthographic = true;
            cam.orthographicSize = 5.5f;
            cam.transform.position = new Vector3(2.5f, 0, -10);
            cam.backgroundColor = new Color(0.10f, 0.12f, 0.18f);
        }

        // 트랙
        GameObject track = new GameObject("Track");
        track.AddComponent<LineRenderer>();
        track.AddComponent<TrackVisualizer>();

        // UI
        BuildUI();

        Debug.Log("도파민 경마 - 씬 구성 완료!");
    }

    private void Start()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnStateChanged += OnStateChanged;
            GameManager.Instance.OnCountdownTick += OnCountdownTick;
        }
        OnStateChanged(GameManager.GameState.Betting);
    }

    private void OnDestroy()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnStateChanged -= OnStateChanged;
            GameManager.Instance.OnCountdownTick -= OnCountdownTick;
        }
    }

    private void Update()
    {
        if (GameManager.Instance == null) return;
        if (GameManager.Instance.CurrentState == GameManager.GameState.Racing)
        {
            raceTimer += Time.deltaTime;
            if (raceTimerText != null) raceTimerText.text = raceTimer.ToString("F1") + "초";

            rankUpdateTimer -= Time.deltaTime;
            if (rankUpdateTimer <= 0f)
            {
                UpdateLiveRankings();
                rankUpdateTimer = 0.3f;
            }
        }
    }

    // ══════════════════════════════════════
    //  UI 구축
    // ══════════════════════════════════════
    private void BuildUI()
    {
        GameObject canvasObj = new GameObject("Canvas");
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 100;

        CanvasScaler sc = canvasObj.AddComponent<CanvasScaler>();
        sc.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        sc.referenceResolution = new Vector2(1920, 1080);
        sc.matchWidthOrHeight = 0.5f;

        canvasObj.AddComponent<GraphicRaycaster>();

        // EventSystem
        if (FindAnyObjectByType<UnityEngine.EventSystems.EventSystem>() == null)
        {
            GameObject es = new GameObject("EventSystem");
            es.AddComponent<UnityEngine.EventSystems.EventSystem>();
            es.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();
        }

        Transform root = canvasObj.transform;

        // ── 배팅 UI ──
        bettingUI = new GameObject("BettingUI");
        bettingUI.transform.SetParent(root, false);
        AddFullRect(bettingUI);
        BuildBettingUI(bettingUI.transform);

        // ── 레이싱 HUD ──
        racingUI = new GameObject("RacingUI");
        racingUI.transform.SetParent(root, false);
        AddFullRect(racingUI);
        BuildRacingUI(racingUI.transform);
        racingUI.SetActive(false);

        // ── 결과 UI ──
        resultUI = new GameObject("ResultUI");
        resultUI.transform.SetParent(root, false);
        AddFullRect(resultUI);
        BuildResultUI(resultUI.transform);
        resultUI.SetActive(false);

        // ── 카운트다운 ──
        countdownUI = new GameObject("Countdown");
        countdownUI.transform.SetParent(root, false);
        RectTransform cdrt = AddFullRect(countdownUI);
        countdownUI.AddComponent<Image>().color = new Color(0, 0, 0, 0.6f);
        countdownText = MkText(countdownUI.transform, "3",
            new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
            Vector2.zero, new Vector2(300, 200), 130, TextAnchor.MiddleCenter, new Color(1f, 0.85f, 0.2f));
        countdownUI.SetActive(false);
    }

    // ── 배팅 화면 구축 ──
    private void BuildBettingUI(Transform parent)
    {
        // === 왼쪽 패널 (선택 목록) ===
        GameObject leftPanel = new GameObject("LeftPanel");
        leftPanel.transform.SetParent(parent, false);
        RectTransform lprt = leftPanel.AddComponent<RectTransform>();
        lprt.anchorMin = new Vector2(0, 0);
        lprt.anchorMax = new Vector2(0.25f, 1);
        lprt.offsetMin = Vector2.zero;
        lprt.offsetMax = Vector2.zero;
        Image lpbg = leftPanel.AddComponent<Image>();
        lpbg.color = new Color(0.95f, 0.85f, 0.15f); // 노란색 배경 (와이어프레임처럼)

        // 타이틀
        titleText = MkText(leftPanel.transform, "우승 선택",
            new Vector2(0.5f, 1), new Vector2(0.5f, 1),
            new Vector2(0, -10), new Vector2(300, 40), 26, TextAnchor.MiddleCenter, Color.black);

        infoText = MkText(leftPanel.transform, "1등 예측을 선택!",
            new Vector2(0.5f, 1), new Vector2(0.5f, 1),
            new Vector2(0, -45), new Vector2(300, 25), 16, TextAnchor.MiddleCenter, new Color(0.3f, 0.3f, 0.3f));

        // 버튼 목록 (스크롤 없이 12개 세로 배치)
        GameObject btnArea = new GameObject("BtnArea");
        btnArea.transform.SetParent(leftPanel.transform, false);
        RectTransform bart = btnArea.AddComponent<RectTransform>();
        bart.anchorMin = new Vector2(0.05f, 0.05f);
        bart.anchorMax = new Vector2(0.95f, 0.88f);
        bart.offsetMin = Vector2.zero;
        bart.offsetMax = Vector2.zero;

        VerticalLayoutGroup vlg = btnArea.AddComponent<VerticalLayoutGroup>();
        vlg.spacing = 4;
        vlg.childForceExpandWidth = true;
        vlg.childForceExpandHeight = true;
        vlg.childControlWidth = true;
        vlg.childControlHeight = true;
        vlg.padding = new RectOffset(5, 5, 5, 5);

        racerButtons = new Button[GameConstants.RACER_COUNT];
        racerTexts = new Text[GameConstants.RACER_COUNT];
        racerLabels = new Text[GameConstants.RACER_COUNT];
        racerBGs = new Image[GameConstants.RACER_COUNT];

        for (int i = 0; i < GameConstants.RACER_COUNT; i++)
        {
            GameObject btn = new GameObject("Btn_" + i);
            btn.transform.SetParent(btnArea.transform, false);

            Image bg = btn.AddComponent<Image>();
            bg.color = Color.white;
            racerBGs[i] = bg;

            Button b = btn.AddComponent<Button>();
            ColorBlock cb = b.colors;
            cb.normalColor = Color.white;
            cb.highlightedColor = new Color(0.9f, 0.9f, 0.7f);
            cb.pressedColor = new Color(0.8f, 0.8f, 0.5f);
            cb.selectedColor = Color.white;
            b.colors = cb;
            racerButtons[i] = b;

            // 색상 점
            GameObject dot = new GameObject("Dot");
            dot.transform.SetParent(btn.transform, false);
            RectTransform drt = dot.AddComponent<RectTransform>();
            drt.anchorMin = new Vector2(0, 0.15f);
            drt.anchorMax = new Vector2(0, 0.85f);
            drt.pivot = new Vector2(0, 0.5f);
            drt.anchoredPosition = new Vector2(8, 0);
            drt.sizeDelta = new Vector2(20, 0);
            Image di = dot.AddComponent<Image>();
            di.color = GameConstants.RACER_COLORS[i];

            // 이름
            GameObject nameObj = new GameObject("Name");
            nameObj.transform.SetParent(btn.transform, false);
            RectTransform nrt = nameObj.AddComponent<RectTransform>();
            nrt.anchorMin = new Vector2(0, 0);
            nrt.anchorMax = new Vector2(0.7f, 1);
            nrt.offsetMin = new Vector2(35, 2);
            nrt.offsetMax = new Vector2(0, -2);
            Text nt = nameObj.AddComponent<Text>();
            nt.font = font;
            nt.text = (i + 1) + ". " + GameConstants.RACER_NAMES[i];
            nt.fontSize = 20;
            nt.color = Color.black;
            nt.alignment = TextAnchor.MiddleLeft;
            nt.resizeTextForBestFit = true;
            nt.resizeTextMinSize = 12;
            nt.resizeTextMaxSize = 20;
            racerTexts[i] = nt;

            // 선택 라벨 (우측)
            GameObject lblObj = new GameObject("Lbl");
            lblObj.transform.SetParent(btn.transform, false);
            RectTransform lrt = lblObj.AddComponent<RectTransform>();
            lrt.anchorMin = new Vector2(0.7f, 0);
            lrt.anchorMax = new Vector2(1, 1);
            lrt.offsetMin = new Vector2(0, 2);
            lrt.offsetMax = new Vector2(-5, -2);
            Text lt = lblObj.AddComponent<Text>();
            lt.font = font;
            lt.text = "";
            lt.fontSize = 18;
            lt.color = new Color(0.8f, 0.1f, 0.1f);
            lt.alignment = TextAnchor.MiddleCenter;
            lt.fontStyle = FontStyle.Bold;
            racerLabels[i] = lt;

            int idx = i;
            b.onClick.AddListener(() => OnRacerClicked(idx));
        }

        // === 우하단 Start 버튼 ===
        GameObject startObj = new GameObject("StartBtn");
        startObj.transform.SetParent(parent, false);
        RectTransform srt = startObj.AddComponent<RectTransform>();
        srt.anchorMin = new Vector2(1, 0);
        srt.anchorMax = new Vector2(1, 0);
        srt.pivot = new Vector2(1, 0);
        srt.anchoredPosition = new Vector2(-30, 20);
        srt.sizeDelta = new Vector2(200, 65);

        Image si = startObj.AddComponent<Image>();
        si.color = new Color(0.95f, 0.85f, 0.15f);

        startButton = startObj.AddComponent<Button>();
        ColorBlock scb = startButton.colors;
        scb.normalColor = new Color(0.95f, 0.85f, 0.15f);
        scb.highlightedColor = new Color(1f, 0.95f, 0.4f);
        scb.pressedColor = new Color(0.8f, 0.7f, 0.1f);
        scb.disabledColor = new Color(0.5f, 0.5f, 0.5f);
        startButton.colors = scb;
        startButton.interactable = false;
        startButton.onClick.AddListener(OnStartClicked);

        MkText(startObj.transform, "Start",
            new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
            Vector2.zero, new Vector2(200, 65), 30, TextAnchor.MiddleCenter, Color.black);

        // === 총점 표시 (우상단) ===
        scoreText = MkText(parent, "총점: 0",
            new Vector2(1, 1), new Vector2(1, 1),
            new Vector2(-20, -15), new Vector2(250, 35), 22, TextAnchor.MiddleRight, Color.white);
    }

    // ── 레이싱 HUD ──
    private void BuildRacingUI(Transform parent)
    {
        // 우측 순위 패널
        GameObject rankPanel = new GameObject("RankPanel");
        rankPanel.transform.SetParent(parent, false);
        RectTransform rrt = rankPanel.AddComponent<RectTransform>();
        rrt.anchorMin = new Vector2(0, 0.02f);
        rrt.anchorMax = new Vector2(0.22f, 0.98f);
        rrt.offsetMin = Vector2.zero;
        rrt.offsetMax = Vector2.zero;
        rankPanel.AddComponent<Image>().color = new Color(0, 0, 0, 0.65f);

        // 순위 텍스트
        VerticalLayoutGroup rvlg = rankPanel.AddComponent<VerticalLayoutGroup>();
        rvlg.spacing = 1;
        rvlg.padding = new RectOffset(8, 8, 8, 8);
        rvlg.childForceExpandWidth = true;
        rvlg.childForceExpandHeight = true;
        rvlg.childControlWidth = true;
        rvlg.childControlHeight = true;

        rankTexts = new Text[GameConstants.RACER_COUNT];
        for (int i = 0; i < GameConstants.RACER_COUNT; i++)
        {
            GameObject ro = new GameObject("R" + i);
            ro.transform.SetParent(rankPanel.transform, false);
            Text rt = ro.AddComponent<Text>();
            rt.font = font;
            rt.fontSize = 16;
            rt.color = Color.white;
            rt.alignment = TextAnchor.MiddleLeft;
            rt.resizeTextForBestFit = true;
            rt.resizeTextMinSize = 10;
            rt.resizeTextMaxSize = 16;
            rankTexts[i] = rt;
        }

        // 내 배팅 표시 (상단 중앙)
        myBetText = MkText(parent, "",
            new Vector2(0.5f, 1), new Vector2(0.5f, 1),
            new Vector2(0, -10), new Vector2(500, 30), 20, TextAnchor.MiddleCenter, new Color(1f, 0.9f, 0.3f));

        // 타이머 (상단 우측)
        raceTimerText = MkText(parent, "0.0초",
            new Vector2(1, 1), new Vector2(1, 1),
            new Vector2(-15, -10), new Vector2(130, 35), 24, TextAnchor.MiddleRight, Color.white);
    }

    // ── 결과 화면 ──
    private void BuildResultUI(Transform parent)
    {
        // 반투명 배경
        Image bg = parent.gameObject.AddComponent<Image>();
        bg.color = new Color(0, 0, 0, 0.75f);

        resultTitleText = MkText(parent, "레이스 결과",
            new Vector2(0.5f, 0.8f), new Vector2(0.5f, 0.8f),
            Vector2.zero, new Vector2(500, 60), 42, TextAnchor.MiddleCenter, new Color(1f, 0.85f, 0.2f));

        resultDetailText = MkText(parent, "",
            new Vector2(0.5f, 0.55f), new Vector2(0.5f, 0.55f),
            Vector2.zero, new Vector2(600, 200), 22, TextAnchor.MiddleCenter, Color.white);

        resultScoreText = MkText(parent, "",
            new Vector2(0.5f, 0.35f), new Vector2(0.5f, 0.35f),
            Vector2.zero, new Vector2(400, 50), 32, TextAnchor.MiddleCenter, Color.yellow);

        // 다음 라운드 버튼
        GameObject nb = new GameObject("NextBtn");
        nb.transform.SetParent(parent, false);
        RectTransform nrt = nb.AddComponent<RectTransform>();
        nrt.anchorMin = new Vector2(0.5f, 0.15f);
        nrt.anchorMax = new Vector2(0.5f, 0.15f);
        nrt.pivot = new Vector2(0.5f, 0.5f);
        nrt.sizeDelta = new Vector2(250, 60);

        nb.AddComponent<Image>().color = new Color(0.25f, 0.5f, 0.9f);
        nextRoundButton = nb.AddComponent<Button>();
        nextRoundButton.onClick.AddListener(() => GameManager.Instance?.NextRound());

        MkText(nb.transform, "다음 라운드",
            new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
            Vector2.zero, new Vector2(250, 60), 26, TextAnchor.MiddleCenter, Color.white);
    }

    // ══════════════════════════════════════
    //  배팅 로직
    // ══════════════════════════════════════
    private void OnRacerClicked(int index)
    {
        if (selectingFirst)
        {
            // 이미 같은거 다시 누르면 해제
            if (selectedFirst == index)
            {
                selectedFirst = -1;
                UpdateButtonVisuals();
                return;
            }
            selectedFirst = index;
            selectingFirst = false;
            infoText.text = "2등 예측을 선택!";
        }
        else
        {
            if (index == selectedFirst)
            {
                // 1등이랑 같은 걸 누르면 1등 해제하고 다시 1등 선택모드
                selectedFirst = -1;
                selectedSecond = -1;
                selectingFirst = true;
                infoText.text = "1등 예측을 선택!";
                UpdateButtonVisuals();
                return;
            }
            if (selectedSecond == index)
            {
                selectedSecond = -1;
                UpdateButtonVisuals();
                return;
            }
            selectedSecond = index;
        }

        UpdateButtonVisuals();
    }

    private void UpdateButtonVisuals()
    {
        for (int i = 0; i < GameConstants.RACER_COUNT; i++)
        {
            if (i == selectedFirst)
            {
                racerBGs[i].color = new Color(1f, 0.7f, 0.7f);
                racerLabels[i].text = "1등";
                racerLabels[i].color = Color.red;
            }
            else if (i == selectedSecond)
            {
                racerBGs[i].color = new Color(0.7f, 0.7f, 1f);
                racerLabels[i].text = "2등";
                racerLabels[i].color = Color.blue;
            }
            else
            {
                racerBGs[i].color = Color.white;
                racerLabels[i].text = "";
            }
        }

        bool ready = (selectedFirst >= 0 && selectedSecond >= 0);
        startButton.interactable = ready;

        if (ready)
            infoText.text = GameConstants.RACER_NAMES[selectedFirst] + "(1등), " + GameConstants.RACER_NAMES[selectedSecond] + "(2등) 선택!";
        else if (selectedFirst >= 0)
            infoText.text = "2등 예측을 선택!";
        else
            infoText.text = "1등 예측을 선택!";
    }

    private void OnStartClicked()
    {
        if (selectedFirst < 0 || selectedSecond < 0) return;
        GameManager.Instance?.PlaceBet(selectedFirst, selectedSecond);
        GameManager.Instance?.StartRace();
    }

    // ══════════════════════════════════════
    //  상태 전환
    // ══════════════════════════════════════
    private void OnStateChanged(GameManager.GameState state)
    {
        bettingUI.SetActive(false);
        racingUI.SetActive(false);
        resultUI.SetActive(false);
        countdownUI.SetActive(false);

        switch (state)
        {
            case GameManager.GameState.Betting:
                bettingUI.SetActive(true);
                ResetBetting();
                UpdateScore();
                break;
            case GameManager.GameState.Countdown:
                countdownUI.SetActive(true);
                break;
            case GameManager.GameState.Racing:
                racingUI.SetActive(true);
                raceTimer = 0f;
                UpdateMyBet();
                break;
            case GameManager.GameState.Result:
                resultUI.SetActive(true);
                ShowResult();
                break;
        }
    }

    private void OnCountdownTick(int t)
    {
        if (countdownText != null)
            countdownText.text = t > 0 ? t.ToString() : "GO!";
    }

    private void ResetBetting()
    {
        selectedFirst = -1;
        selectedSecond = -1;
        selectingFirst = true;
        if (infoText != null) infoText.text = "1등 예측을 선택!";
        UpdateButtonVisuals();
    }

    private void UpdateScore()
    {
        if (scoreText != null && ScoreManager.Instance != null)
            scoreText.text = "총점: " + ScoreManager.Instance.TotalScore;
    }

    private void UpdateMyBet()
    {
        if (myBetText == null || GameManager.Instance == null) return;
        int f = GameManager.Instance.BetFirst;
        int s = GameManager.Instance.BetSecond;
        if (f >= 0 && s >= 0)
            myBetText.text = "내 배팅 ▶ 1등: " + GameConstants.RACER_NAMES[f] + "  2등: " + GameConstants.RACER_NAMES[s];
    }

    private void UpdateLiveRankings()
    {
        if (RaceManager.Instance == null || rankTexts == null) return;
        var live = RaceManager.Instance.GetLiveRankings();
        int bF = GameManager.Instance?.BetFirst ?? -1;
        int bS = GameManager.Instance?.BetSecond ?? -1;

        for (int i = 0; i < rankTexts.Length && i < live.Count; i++)
        {
            var r = live[i];
            string mark = r.RacerIndex == bF ? " ★" : r.RacerIndex == bS ? " ☆" : "";
            string st = r.IsFinished ? "완주" : "x" + r.CurrentSpeed.ToString("F1");
            rankTexts[i].text = (i + 1) + ". " + GameConstants.RACER_NAMES[r.RacerIndex] + " " + st + mark;
            rankTexts[i].color = (r.RacerIndex == bF || r.RacerIndex == bS)
                ? new Color(1f, 0.9f, 0.3f) : Color.white;
        }
    }

    private void ShowResult()
    {
        var rankings = RaceManager.Instance?.GetFinalRankings();
        if (rankings == null || rankings.Count < 3) return;

        int bF = GameManager.Instance.BetFirst;
        int bS = GameManager.Instance.BetSecond;
        int score = ScoreManager.Instance?.LastRoundScore ?? 0;

        resultTitleText.text = score > 0 ? "축하합니다!" : "아쉽네요...";
        resultTitleText.color = score > 0 ? new Color(1f, 0.85f, 0.2f) : new Color(0.7f, 0.7f, 0.7f);

        bool fOK = rankings[0].racerIndex == bF;
        bool sOK = rankings[1].racerIndex == bS;
        string fName = bF >= 0 ? GameConstants.RACER_NAMES[bF] : "???";
        string sName = bS >= 0 ? GameConstants.RACER_NAMES[bS] : "???";

        string detail = "";
        detail += "1등: " + rankings[0].racerName + "  /  2등: " + rankings[1].racerName + "  /  3등: " + rankings[2].racerName + "\n\n";
        detail += "내 1등 예측: " + fName + " → " + (fOK ? "적중! (+3점)" : "실패") + "\n";
        detail += "내 2등 예측: " + sName + " → " + (sOK ? "적중! (+1점)" : "실패");
        resultDetailText.text = detail;

        resultScoreText.text = score > 0
            ? "+" + score + "점 획득!  (총점: " + ScoreManager.Instance.TotalScore + ")"
            : "0점  (총점: " + ScoreManager.Instance.TotalScore + ")";
        resultScoreText.color = score > 0 ? Color.yellow : new Color(0.7f, 0.7f, 0.7f);
    }

    // ══════════════════════════════════════
    //  유틸리티
    // ══════════════════════════════════════
    private RectTransform AddFullRect(GameObject obj)
    {
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        return rt;
    }

    private Text MkText(Transform parent, string text,
        Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size,
        int fontSize, TextAnchor align, Color? color = null)
    {
        GameObject o = new GameObject("T");
        o.transform.SetParent(parent, false);
        RectTransform rt = o.AddComponent<RectTransform>();
        rt.anchorMin = anchor; rt.anchorMax = anchor; rt.pivot = pivot;
        rt.anchoredPosition = pos; rt.sizeDelta = size;

        Text t = o.AddComponent<Text>();
        t.font = font; t.text = text; t.fontSize = fontSize;
        t.alignment = align; t.color = color ?? Color.white;
        t.horizontalOverflow = HorizontalWrapMode.Overflow;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.supportRichText = true;
        return t;
    }
}
