using UnityEngine;
using System;

public class ScoreManager : MonoBehaviour
{
    public static ScoreManager Instance { get; private set; }
    public int TotalScore { get; private set; }
    public int TotalRounds { get; private set; }
    public int TotalWins { get; private set; }
    public int LastRoundScore { get; private set; }
    public float WinRate => TotalRounds > 0 ? (float)TotalWins / TotalRounds * 100f : 0f;
    public event Action<int, int> OnScoreChanged;

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        TotalScore = PlayerPrefs.GetInt("S", 0);
        TotalRounds = PlayerPrefs.GetInt("R", 0);
        TotalWins = PlayerPrefs.GetInt("W", 0);
    }

    public void AddScore(int a)
    {
        LastRoundScore = a;
        TotalScore += a; TotalRounds++;
        if (a > 0) TotalWins++;
        PlayerPrefs.SetInt("S", TotalScore);
        PlayerPrefs.SetInt("R", TotalRounds);
        PlayerPrefs.SetInt("W", TotalWins);
        PlayerPrefs.Save();
        OnScoreChanged?.Invoke(a, TotalScore);
    }
}
