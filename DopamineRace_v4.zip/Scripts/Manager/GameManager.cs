using UnityEngine;
using System;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }
    public enum GameState { Betting, Countdown, Racing, Result }
    public GameState CurrentState { get; private set; } = GameState.Betting;

    public event Action<GameState> OnStateChanged;
    public event Action<int> OnCountdownTick;
    public event Action OnRaceStart;

    private float countdownTimer;
    public int BetFirst { get; private set; } = -1;
    public int BetSecond { get; private set; } = -1;

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    private void Start() { ChangeState(GameState.Betting); }

    private void Update()
    {
        if (CurrentState == GameState.Countdown)
        {
            countdownTimer -= Time.deltaTime;
            OnCountdownTick?.Invoke(Mathf.CeilToInt(countdownTimer));
            if (countdownTimer <= 0f) ChangeState(GameState.Racing);
        }
    }

    public void ChangeState(GameState s)
    {
        CurrentState = s;
        if (s == GameState.Betting) { BetFirst = -1; BetSecond = -1; }
        if (s == GameState.Countdown) countdownTimer = 3f;
        if (s == GameState.Racing) OnRaceStart?.Invoke();
        if (s == GameState.Result) CalcScore();
        OnStateChanged?.Invoke(s);
    }

    public void PlaceBet(int first, int second) { BetFirst = first; BetSecond = second; }

    public void StartRace()
    {
        if (BetFirst < 0 || BetSecond < 0 || BetFirst == BetSecond) return;
        ChangeState(GameState.Countdown);
    }

    private void CalcScore()
    {
        var r = RaceManager.Instance?.GetFinalRankings();
        if (r == null || r.Count < 2) return;
        int score = 0;
        if (r[0].racerIndex == BetFirst) score += GameConstants.FIRST_PLACE_SCORE;
        if (r[1].racerIndex == BetSecond) score += GameConstants.SECOND_PLACE_SCORE;
        ScoreManager.Instance?.AddScore(score);
    }

    public void NextRound()
    {
        RaceManager.Instance?.ResetRace();
        ChangeState(GameState.Betting);
    }
}
