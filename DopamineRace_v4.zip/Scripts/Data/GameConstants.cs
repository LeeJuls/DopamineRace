using UnityEngine;

public static class GameConstants
{
    public const int RACER_COUNT = 12;
    public const float RACER_MIN_SPEED = 2.0f;
    public const float RACER_MAX_SPEED = 6.0f;
    public const float SPEED_CHANGE_INTERVAL = 3f;
    public const float SPEED_LERP_RATE = 3f;
    public const int WAYPOINT_COUNT = 24;
    public const float TRACK_RADIUS_X = 5.5f;
    public const float TRACK_RADIUS_Y = 3.2f;
    public const int TOTAL_LAPS = 1;
    public const int FIRST_PLACE_SCORE = 3;
    public const int SECOND_PLACE_SCORE = 1;

    public static readonly string[] RACER_NAMES = new string[]
    {
        "번개", "태풍", "혜성", "로켓",
        "불꽃", "질풍", "천둥", "유성",
        "폭풍", "섬광", "회오리", "울트라"
    };

    public static readonly Color[] RACER_COLORS = new Color[]
    {
        new Color(0.90f, 0.20f, 0.20f),
        new Color(0.20f, 0.50f, 0.90f),
        new Color(0.20f, 0.80f, 0.30f),
        new Color(0.95f, 0.75f, 0.10f),
        new Color(0.80f, 0.30f, 0.80f),
        new Color(1.00f, 0.50f, 0.10f),
        new Color(0.10f, 0.80f, 0.80f),
        new Color(0.90f, 0.40f, 0.60f),
        new Color(0.50f, 0.30f, 0.10f),
        new Color(0.60f, 0.60f, 0.60f),
        new Color(0.00f, 0.50f, 0.25f),
        new Color(0.40f, 0.20f, 0.60f),
    };
}
