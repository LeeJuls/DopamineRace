using UnityEngine;
using System;
using System.Collections.Generic;

public class RacerController : MonoBehaviour
{
    private int racerIndex;
    private float currentSpeed = 0f;
    private float targetSpeed = 0f;
    private int currentWP = 0;
    private int currentLap = 0;
    private bool isRacing = false;
    private bool isFinished = false;
    private List<Transform> waypoints;
    private float speedTimer;
    private float laneOffset; // 각 레이서별 고정 레인

    public int RacerIndex => racerIndex;
    public bool IsFinished => isFinished;
    public int FinishOrder { get; set; } = -1;
    public float CurrentSpeed => currentSpeed;
    public float TotalProgress => isFinished ? float.MaxValue :
        (waypoints == null || waypoints.Count == 0) ? 0 :
        currentLap + (float)currentWP / waypoints.Count;

    public event Action<RacerController> OnFinished;

    public void Initialize(int index, List<Transform> wps)
    {
        racerIndex = index;
        waypoints = wps;
        // 각 레이서에 고정 레인 부여 (안쪽~바깥쪽)
        laneOffset = (index - GameConstants.RACER_COUNT / 2f) * 0.08f;
    }

    public void StartRacing()
    {
        isRacing = true; isFinished = false; FinishOrder = -1;
        currentWP = 0; currentLap = 0; speedTimer = 0f;
        targetSpeed = UnityEngine.Random.Range(GameConstants.RACER_MIN_SPEED, GameConstants.RACER_MAX_SPEED);
        currentSpeed = targetSpeed * 0.5f; // 초기 속도
    }

    public void ResetRacer(Vector3 pos)
    {
        isRacing = false; isFinished = false; FinishOrder = -1;
        currentSpeed = 0f; targetSpeed = 0f; currentWP = 0; currentLap = 0;
        transform.position = pos;
    }

    private void Update()
    {
        if (!isRacing || isFinished) return;
        if (waypoints == null || waypoints.Count == 0) return;

        // 3초마다 속도 랜덤 변경
        speedTimer -= Time.deltaTime;
        if (speedTimer <= 0f)
        {
            targetSpeed = UnityEngine.Random.Range(GameConstants.RACER_MIN_SPEED, GameConstants.RACER_MAX_SPEED);
            speedTimer = GameConstants.SPEED_CHANGE_INTERVAL;
        }
        currentSpeed = Mathf.Lerp(currentSpeed, targetSpeed, Time.deltaTime * GameConstants.SPEED_LERP_RATE);

        // 현재 목표 웨이포인트 위치 (레인 오프셋 적용)
        Vector3 wpPos = waypoints[currentWP].position;

        // 트랙 중심에서 바깥 방향으로 레인 오프셋
        Vector3 trackCenter = new Vector3(2f, 0f, 0f); // 트랙 중심
        Vector3 outward = (wpPos - trackCenter).normalized;
        Vector3 targetPos = wpPos + outward * laneOffset;

        Vector3 dir = targetPos - transform.position;
        float dist = dir.magnitude;

        if (dist < 0.3f)
        {
            // 다음 웨이포인트로 진행
            currentWP++;
            if (currentWP >= waypoints.Count)
            {
                currentWP = 0;
                currentLap++;
                if (currentLap >= GameConstants.TOTAL_LAPS)
                {
                    // 완주!
                    isFinished = true;
                    isRacing = false;
                    currentSpeed = 0f;
                    OnFinished?.Invoke(this);
                    return;
                }
            }
        }
        else
        {
            // 웨이포인트를 향해 이동
            float step = currentSpeed * Time.deltaTime;
            transform.position += dir.normalized * Mathf.Min(step, dist);
        }
    }
}
