using UnityEngine;

[RequireComponent(typeof(LineRenderer))]
public class TrackVisualizer : MonoBehaviour
{
    private void Start() { DrawTrack(); }

    public void DrawTrack()
    {
        // 트랙 중심을 오른쪽으로 이동 (왼쪽에 UI 공간 확보)
        transform.position = new Vector3(2f, 0, 0);

        LineRenderer main = GetComponent<LineRenderer>();
        SetupLine(main, new Color(0.35f, 0.30f, 0.25f), 1.0f);
        DrawEllipse(main, 0f);

        LineRenderer inner = NewLR("Inner");
        SetupLine(inner, Color.white, 0.04f);
        DrawEllipse(inner, -0.6f);

        LineRenderer outer = NewLR("Outer");
        SetupLine(outer, Color.white, 0.04f);
        DrawEllipse(outer, 0.6f);

        LineRenderer sl = NewLR("Start");
        SetupLine(sl, Color.red, 0.06f);
        sl.positionCount = 2;
        sl.SetPosition(0, new Vector3(0, GameConstants.TRACK_RADIUS_Y - 0.6f, 0.05f));
        sl.SetPosition(1, new Vector3(0, GameConstants.TRACK_RADIUS_Y + 0.6f, 0.05f));
    }

    private LineRenderer NewLR(string name)
    {
        GameObject o = new GameObject(name);
        o.transform.SetParent(transform); o.transform.localPosition = Vector3.zero;
        return o.AddComponent<LineRenderer>();
    }

    private void DrawEllipse(LineRenderer lr, float m)
    {
        int seg = 80; lr.positionCount = seg + 1;
        float rx = GameConstants.TRACK_RADIUS_X + m, ry = GameConstants.TRACK_RADIUS_Y + m;
        for (int i = 0; i <= seg; i++)
        {
            float a = (float)i / seg * Mathf.PI * 2f;
            lr.SetPosition(i, new Vector3(rx * Mathf.Sin(a), ry * Mathf.Cos(a), 0.1f));
        }
    }

    private void SetupLine(LineRenderer lr, Color c, float w)
    {
        lr.startWidth = w; lr.endWidth = w; lr.startColor = c; lr.endColor = c;
        lr.useWorldSpace = false; lr.sortingOrder = 1;
        lr.material = new Material(Shader.Find("Sprites/Default"));
        lr.material.color = c;
    }
}
