using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class RaceManager : MonoBehaviour
{
    public static RaceManager Instance { get; private set; }
    private List<Transform> waypoints = new List<Transform>();
    private List<RacerController> racers = new List<RacerController>();
    private List<RankingEntry> finalRankings = new List<RankingEntry>();
    private int finishedCount = 0;
    public bool RaceActive { get; private set; }
    public List<RacerController> Racers => racers;

    public static readonly Vector3 TrackCenter = new Vector3(3.5f, 0f, 0f);
    private List<int> spawnIndices = new List<int>();
    private SpawnPositionData spawnData;

    // ★ 라운드별 바퀴 수 (SetLaps로 변경)
    private int currentLaps;
    public int CurrentLaps => currentLaps;

    public struct RankingEntry
    {
        public int racerIndex; public string racerName; public Color racerColor; public int rank;
    }

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        currentLaps = GameConstants.TOTAL_LAPS; // 기본값
    }

    private void Start()
    {
        GenerateTrack(); SpawnRacers();
        if (GameManager.Instance != null) GameManager.Instance.OnRaceStart += StartRace;
    }

    private void OnDestroy()
    {
        if (GameManager.Instance != null) GameManager.Instance.OnRaceStart -= StartRace;
    }

    /// <summary>
    /// ★ 라운드별 바퀴 수 설정
    /// </summary>
    public void SetLaps(int laps)
    {
        currentLaps = Mathf.Max(1, laps);
        Debug.Log("[RaceManager] 바퀴 수 설정: " + currentLaps);
    }

    public void GenerateTrack()
    {
        GameObject p = new GameObject("Waypoints");
        p.transform.SetParent(transform);
        waypoints.Clear();

        var trackData = TrackPathData.Load();
        Debug.Log("★ 트랙 웨이포인트 로드: " + trackData.Count + "개");

        for (int i = 0; i < trackData.Count; i++)
        {
            GameObject wp = new GameObject("WP_" + i);
            wp.transform.SetParent(p.transform);
            Vector2 pt = trackData.GetPoint(i);
            wp.transform.position = new Vector3(pt.x, pt.y, 0);
            waypoints.Add(wp.transform);
            Debug.Log("  WP" + i + ": (" + pt.x + ", " + pt.y + ")");
        }
    }

    private void SpawnRacers()
    {
        var settings = GameSettings.Instance;
        GameObject p = new GameObject("Racers");
        p.transform.SetParent(transform);

        spawnData = SpawnPositionData.Load();
        Debug.Log("★ 스폰 위치 로드: " + spawnData.Count + "개");

        ShuffleSpawnPositions(settings.racerCount);

        for (int i = 0; i < settings.racerCount; i++)
        {
            GameObject obj = LoadPixemCharacter(i);
            if (obj == null)
            {
                Debug.LogError("Character_" + i + " 프리팹을 로드할 수 없습니다!");
                obj = MakeFallbackRacer(i);
            }

            obj.transform.SetParent(p.transform);
            obj.name = "Racer_" + GameConstants.RACER_NAMES[i];

            // ★ 순서 중요: 1) 위치 설정 → 2) Initialize → 3) ConfirmSpawnPosition
            int spawnIdx = spawnIndices[i];
            Vector2 spawnPos = GetSpawnPosition(spawnIdx, settings);
            obj.transform.position = new Vector3(spawnPos.x, spawnPos.y, 0);

            RacerController c = obj.AddComponent<RacerController>();
            c.Initialize(i, waypoints);
            c.ConfirmSpawnPosition();

            racers.Add(c);

            Debug.Log("★ Racer " + i + " (" + GameConstants.RACER_NAMES[i] + ") → 스폰위치: " + spawnPos);
        }
    }

    private void ShuffleSpawnPositions(int count)
    {
        spawnIndices.Clear();
        for (int i = 0; i < count; i++)
            spawnIndices.Add(i);
        for (int i = count - 1; i > 0; i--)
        {
            int j = UnityEngine.Random.Range(0, i + 1);
            int temp = spawnIndices[i];
            spawnIndices[i] = spawnIndices[j];
            spawnIndices[j] = temp;
        }
    }

    private Vector2 GetSpawnPosition(int spawnIdx, GameSettings settings)
    {
        if (spawnData != null && spawnIdx < spawnData.Count)
            return spawnData.GetPoint(spawnIdx);
        int col = spawnIdx % 3;
        int row = spawnIdx / 3;
        return new Vector2(
            waypoints[0].position.x + (col - 1) * 0.35f,
            waypoints[0].position.y - row * 0.35f
        );
    }

    private GameObject LoadPixemCharacter(int index)
    {
        var settings = GameSettings.Instance;
        string path = "CharacterPrefabs/Character_" + index;
        GameObject prefab = Resources.Load<GameObject>(path);

        if (prefab == null)
        {
            Debug.LogWarning("프리팹 없음: " + path);
            return null;
        }

        GameObject obj = Instantiate(prefab);
        obj.transform.localScale = new Vector3(settings.characterScale, settings.characterScale, 1f);

        SpriteRenderer[] srs = obj.GetComponentsInChildren<SpriteRenderer>();
        foreach (var sr in srs)
        {
            sr.sortingOrder = 10 + index;
        }

        // 번호 라벨
        GameObject lb = new GameObject("RaceLabel");
        lb.transform.SetParent(obj.transform);
        lb.transform.localPosition = new Vector3(0, settings.labelHeight, 0);
        lb.transform.localScale = Vector3.one;
        TextMesh tm = lb.AddComponent<TextMesh>();
        tm.text = (index + 1).ToString();
        tm.alignment = TextAlignment.Center;
        tm.anchor = TextAnchor.MiddleCenter;
        tm.characterSize = settings.labelSize;
        tm.fontSize = 48;
        tm.fontStyle = FontStyle.Bold;
        tm.color = GameConstants.RACER_COLORS[index];
        lb.GetComponent<MeshRenderer>().sortingOrder = 20 + index;

        return obj;
    }

    private GameObject MakeFallbackRacer(int i)
    {
        GameObject obj = new GameObject();
        SpriteRenderer sr = obj.AddComponent<SpriteRenderer>();
        sr.sprite = MakeCircle();
        sr.color = GameConstants.RACER_COLORS[i];
        sr.sortingOrder = 10 + i;
        obj.transform.localScale = new Vector3(0.28f, 0.28f, 1f);
        return obj;
    }

    private Sprite MakeCircle()
    {
        int s = 64; Texture2D t = new Texture2D(s, s, TextureFormat.RGBA32, false);
        float r = s / 2f;
        for (int x = 0; x < s; x++)
            for (int y = 0; y < s; y++)
            {
                float d = Vector2.Distance(new Vector2(x, y), new Vector2(r, r));
                t.SetPixel(x, y, d < r - 2 ? Color.white :
                    d < r - 1 ? new Color(0.2f, 0.2f, 0.2f) : Color.clear);
            }
        t.Apply(); t.filterMode = FilterMode.Point;
        return Sprite.Create(t, new Rect(0, 0, s, s), new Vector2(0.5f, 0.5f), 64f);
    }

    public void StartRace()
    {
        RaceActive = true; finishedCount = 0; finalRankings.Clear();
        Debug.Log("═══ 레이스 시작! (" + currentLaps + "바퀴) ═══");
        foreach (var r in racers) { r.StartRacing(); r.OnFinished += OnFinish; }
    }

    private void OnFinish(RacerController r)
    {
        finishedCount++; r.OnFinished -= OnFinish;
        r.FinishOrder = finishedCount;  // ★ 도착 순서 기록
        finalRankings.Add(new RankingEntry {
            racerIndex = r.RacerIndex, racerName = GameConstants.RACER_NAMES[r.RacerIndex],
            racerColor = GameConstants.RACER_COLORS[r.RacerIndex], rank = finishedCount });
        Debug.Log(finishedCount + "등 완주: " + GameConstants.RACER_NAMES[r.RacerIndex]);
        if (finishedCount >= GameSettings.Instance.racerCount)
        {
            RaceActive = false;
            GameManager.Instance?.ChangeState(GameManager.GameState.Result);
        }
    }

    public List<RacerController> GetLiveRankings()
    {
        // 완주자: FinishOrder 오름차순 (1등 먼저)
        // 미완주자: TotalProgress 내림차순 (앞서가는 순)
        return racers
            .OrderByDescending(r => r.IsFinished ? 1 : 0)
            .ThenBy(r => r.IsFinished ? r.FinishOrder : 0)
            .ThenByDescending(r => r.TotalProgress)
            .ToList();
    }

    public List<RankingEntry> GetFinalRankings() => finalRankings;

    public void ResetRace()
    {
        var settings = GameSettings.Instance;
        RaceActive = false; finishedCount = 0; finalRankings.Clear();

        spawnData = SpawnPositionData.Load();
        ShuffleSpawnPositions(racers.Count);

        for (int i = 0; i < racers.Count; i++)
        {
            int spawnIdx = spawnIndices[i];
            Vector2 spawnPos = GetSpawnPosition(spawnIdx, settings);
            racers[i].ResetRacer(new Vector3(spawnPos.x, spawnPos.y, 0));
        }
    }
}