using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

/// <summary>
/// 와이어프레임 기반 레이아웃:
/// [왼쪽] 배팅 타입 탭 + 우승 선택 패널
/// [중앙] 레이스 경기장
/// [우상단] 라운드/바퀴/점수 표시
/// [우하단] Start 버튼
/// </summary>
public class SceneBootstrapper : MonoBehaviour
{
    private Font font;

    // UI 참조 ── 배팅
    private Button[] racerButtons;
    private Text[] racerTexts;
    private Text[] racerLabels;
    private Image[] racerBGs;
    private Button startButton;
    private Text titleText;
    private Text infoText;
    private Text scoreText;
    private Text roundText;         // ★ "Round 2/7"
    private Text lapText;           // ★ "이번 경기: 2바퀴"
    private GameObject leftPanelObj;
    private Text toggleBtnText;

    // 배팅 타입 탭
    private Button[] betTypeBtns;
    private Text[] betTypeBtnTexts;
    private Image[] betTypeBtnBGs;
    private BetType currentTabType = BetType.Exacta;

    // 레이스 중 UI
    private GameObject bettingUI;
    private GameObject racingUI;
    private GameObject resultUI;
    private GameObject countdownUI;
    private Text countdownText;
    private Text raceTimerText;
    private Text[] rankTexts;
    private Text myBetText;
    private Text racingRoundText;   // ★ 레이싱 중 라운드 표시

    // 결과 UI
    private Text resultTitleText;
    private Text resultDetailText;
    private Text resultScoreText;
    private Button nextRoundButton;
    private Text nextRoundBtnText;

    // Finish UI (★ STEP5)
    private GameObject finishUI;
    private Text finishTitleText;
    private Text finishRoundDetailText;
    private Text finishTotalScoreText;

    // 리더보드 팝업 (★ STEP5)
    private GameObject leaderboardPopup;
    private Text leaderboardContentText;
    private Text leaderboardTitleText;

    private float raceTimer;
    private float rankUpdateTimer;
    private List<GameObject> betArrows = new List<GameObject>();

    private void Awake()
    {
        if (GameManager.Instance != null) return;

        font = Font.CreateDynamicFontFromOSFont("Malgun Gothic", 24);
        if (font == null) font = Font.CreateDynamicFontFromOSFont("Arial", 24);

        // 매니저 생성
        new GameObject("GameManager").AddComponent<GameManager>();
        new GameObject("RaceManager").AddComponent<RaceManager>();
        new GameObject("ScoreManager").AddComponent<ScoreManager>();

        // 카메라 설정
        Camera cam = Camera.main;
        if (cam != null)
        {
            cam.orthographic = true;
            cam.orthographicSize = 5.5f;
            cam.transform.position = new Vector3(2.5f, 0, -10);
            cam.backgroundColor = new Color(0.10f, 0.10f, 0.35f);
        }

        // 트랙
        GameObject track = new GameObject("Track");
        track.AddComponent<TrackVisualizer>();
        track.AddComponent<TrackEditor>();
        track.AddComponent<TrackDebugPath>();
        track.AddComponent<SpawnEditor>();

        BuildUI();
        Debug.Log("도파민 경마 - 씬 구성 완료!");
    }

    private void Start()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnStateChanged += OnStateChanged;
            GameManager.Instance.OnCountdownTick += OnCountdownTick;
        }
        OnStateChanged(GameManager.GameState.Betting);
        // ★ 스폰 후 1프레임 뒤에 라벨 숨기기
        StartCoroutine(HideLabelsNextFrame());
    }

    private System.Collections.IEnumerator HideLabelsNextFrame()
    {
        yield return null;
        HideAllRaceLabels();
    }

    private void OnDestroy()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnStateChanged -= OnStateChanged;
            GameManager.Instance.OnCountdownTick -= OnCountdownTick;
        }
    }

    private void Update()
    {
        if (GameManager.Instance == null) return;
        if (GameManager.Instance.CurrentState == GameManager.GameState.Racing)
        {
            raceTimer += Time.deltaTime;
            if (raceTimerText != null) raceTimerText.text = raceTimer.ToString("F1") + "초";

            rankUpdateTimer -= Time.deltaTime;
            if (rankUpdateTimer <= 0f)
            {
                UpdateLiveRankings();
                rankUpdateTimer = 0.3f;
            }
            UpdateArrowPositions();
        }
    }

    // ══════════════════════════════════════
    //  UI 구축
    // ══════════════════════════════════════
    private void BuildUI()
    {
        GameObject canvasObj = new GameObject("Canvas");
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 100;

        CanvasScaler sc = canvasObj.AddComponent<CanvasScaler>();
        sc.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        sc.referenceResolution = new Vector2(1920, 1080);
        sc.matchWidthOrHeight = 0.5f;

        canvasObj.AddComponent<GraphicRaycaster>();

        if (FindAnyObjectByType<UnityEngine.EventSystems.EventSystem>() == null)
        {
            GameObject es = new GameObject("EventSystem");
            es.AddComponent<UnityEngine.EventSystems.EventSystem>();
            es.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();
        }

        Transform root = canvasObj.transform;

        // ── 배팅 UI ──
        bettingUI = new GameObject("BettingUI");
        bettingUI.transform.SetParent(root, false);
        AddFullRect(bettingUI);
        BuildBettingUI(bettingUI.transform);

        // ── 레이싱 HUD ──
        racingUI = new GameObject("RacingUI");
        racingUI.transform.SetParent(root, false);
        AddFullRect(racingUI);
        BuildRacingUI(racingUI.transform);
        racingUI.SetActive(false);

        // ── 결과 UI ──
        resultUI = new GameObject("ResultUI");
        resultUI.transform.SetParent(root, false);
        AddFullRect(resultUI);
        BuildResultUI(resultUI.transform);
        resultUI.SetActive(false);

        // ── 카운트다운 ──
        countdownUI = new GameObject("Countdown");
        countdownUI.transform.SetParent(root, false);
        AddFullRect(countdownUI);
        countdownUI.AddComponent<Image>().color = new Color(0, 0, 0, 0.6f);
        countdownText = MkText(countdownUI.transform, "3",
            new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
            Vector2.zero, new Vector2(300, 200), 130, TextAnchor.MiddleCenter, new Color(1f, 0.85f, 0.2f));
        countdownUI.SetActive(false);

        // ── Finish UI (★ STEP5) ──
        finishUI = new GameObject("FinishUI");
        finishUI.transform.SetParent(root, false);
        AddFullRect(finishUI);
        BuildFinishUI(finishUI.transform);
        finishUI.SetActive(false);

        // ── 리더보드 팝업 (★ STEP5) ──
        leaderboardPopup = new GameObject("LeaderboardPopup");
        leaderboardPopup.transform.SetParent(root, false);
        AddFullRect(leaderboardPopup);
        BuildLeaderboardPopup(leaderboardPopup.transform);
        leaderboardPopup.SetActive(false);
    }

    // ══════════════════════════════════════
    //  배팅 화면
    // ══════════════════════════════════════
    private void BuildBettingUI(Transform parent)
    {
        // === 왼쪽 패널 ===
        GameObject leftPanel = new GameObject("LeftPanel");
        leftPanel.transform.SetParent(parent, false);
        RectTransform lprt = leftPanel.AddComponent<RectTransform>();
        lprt.anchorMin = new Vector2(0, 0);
        lprt.anchorMax = new Vector2(0.25f, 1);
        lprt.offsetMin = Vector2.zero;
        lprt.offsetMax = Vector2.zero;
        Image lpbg = leftPanel.AddComponent<Image>();
        lpbg.color = new Color(0.95f, 0.85f, 0.15f);
        leftPanelObj = leftPanel;

        // 닫기/열기 토글 버튼
        GameObject toggleBtn = new GameObject("ToggleBtn");
        toggleBtn.transform.SetParent(parent, false);
        RectTransform trt = toggleBtn.AddComponent<RectTransform>();
        trt.anchorMin = new Vector2(0, 1);
        trt.anchorMax = new Vector2(0, 1);
        trt.pivot = new Vector2(0, 1);
        trt.anchoredPosition = new Vector2(5, -5);
        trt.sizeDelta = new Vector2(80, 35);
        toggleBtn.AddComponent<Image>().color = new Color(0.3f, 0.3f, 0.3f, 0.9f);
        Button tb = toggleBtn.AddComponent<Button>();
        tb.onClick.AddListener(() => {
            bool isOpen = leftPanelObj.activeSelf;
            leftPanelObj.SetActive(!isOpen);
            toggleBtnText.text = isOpen ? "열기 ▶" : "◀ 닫기";
        });
        toggleBtnText = MkText(toggleBtn.transform, "◀ 닫기",
            new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
            Vector2.zero, new Vector2(80, 35), 18, TextAnchor.MiddleCenter, Color.white);

        // ── 배팅 타입 탭 (상단) ──
        BuildBetTypeTabs(leftPanel.transform);

        // 타이틀 + 안내
        titleText = MkText(leftPanel.transform, "배팅 선택",
            new Vector2(0.5f, 1), new Vector2(0.5f, 1),
            new Vector2(0, -75), new Vector2(300, 30), 22, TextAnchor.MiddleCenter, Color.black);

        infoText = MkText(leftPanel.transform, "",
            new Vector2(0.5f, 1), new Vector2(0.5f, 1),
            new Vector2(0, -100), new Vector2(300, 25), 15, TextAnchor.MiddleCenter, new Color(0.3f, 0.3f, 0.3f));

        // 버튼 목록
        GameObject btnArea = new GameObject("BtnArea");
        btnArea.transform.SetParent(leftPanel.transform, false);
        RectTransform bart = btnArea.AddComponent<RectTransform>();
        bart.anchorMin = new Vector2(0.05f, 0.05f);
        bart.anchorMax = new Vector2(0.95f, 0.82f);
        bart.offsetMin = Vector2.zero;
        bart.offsetMax = Vector2.zero;

        VerticalLayoutGroup vlg = btnArea.AddComponent<VerticalLayoutGroup>();
        vlg.spacing = 4;
        vlg.childForceExpandWidth = true;
        vlg.childForceExpandHeight = true;
        vlg.childControlWidth = true;
        vlg.childControlHeight = true;
        vlg.padding = new RectOffset(5, 5, 5, 5);

        racerButtons = new Button[GameConstants.RACER_COUNT];
        racerTexts = new Text[GameConstants.RACER_COUNT];
        racerLabels = new Text[GameConstants.RACER_COUNT];
        racerBGs = new Image[GameConstants.RACER_COUNT];

        for (int i = 0; i < GameConstants.RACER_COUNT; i++)
        {
            GameObject btn = new GameObject("Btn_" + i);
            btn.transform.SetParent(btnArea.transform, false);

            Image bg = btn.AddComponent<Image>();
            bg.color = Color.white;
            racerBGs[i] = bg;

            Button b = btn.AddComponent<Button>();
            ColorBlock cb = b.colors;
            cb.normalColor = Color.white;
            cb.highlightedColor = new Color(0.9f, 0.9f, 0.7f);
            cb.pressedColor = new Color(0.8f, 0.8f, 0.5f);
            cb.selectedColor = Color.white;
            b.colors = cb;
            racerButtons[i] = b;

            // 색상 점
            GameObject dot = new GameObject("Dot");
            dot.transform.SetParent(btn.transform, false);
            RectTransform drt = dot.AddComponent<RectTransform>();
            drt.anchorMin = new Vector2(0, 0.15f);
            drt.anchorMax = new Vector2(0, 0.85f);
            drt.pivot = new Vector2(0, 0.5f);
            drt.anchoredPosition = new Vector2(8, 0);
            drt.sizeDelta = new Vector2(20, 0);
            dot.AddComponent<Image>().color = GameConstants.RACER_COLORS[i];

            // 이름
            GameObject nameObj = new GameObject("Name");
            nameObj.transform.SetParent(btn.transform, false);
            RectTransform nrt = nameObj.AddComponent<RectTransform>();
            nrt.anchorMin = new Vector2(0, 0);
            nrt.anchorMax = new Vector2(0.7f, 1);
            nrt.offsetMin = new Vector2(35, 2);
            nrt.offsetMax = new Vector2(0, -2);
            Text nt = nameObj.AddComponent<Text>();
            nt.font = font;
            nt.text = (i + 1) + ". " + GameConstants.RACER_NAMES[i];
            nt.fontSize = 20;
            nt.color = Color.black;
            nt.alignment = TextAnchor.MiddleLeft;
            nt.resizeTextForBestFit = true;
            nt.resizeTextMinSize = 12;
            nt.resizeTextMaxSize = 20;
            racerTexts[i] = nt;

            // 선택 라벨 (우측)
            GameObject lblObj = new GameObject("Lbl");
            lblObj.transform.SetParent(btn.transform, false);
            RectTransform lrt = lblObj.AddComponent<RectTransform>();
            lrt.anchorMin = new Vector2(0.7f, 0);
            lrt.anchorMax = new Vector2(1, 1);
            lrt.offsetMin = new Vector2(0, 2);
            lrt.offsetMax = new Vector2(-5, -2);
            Text lt = lblObj.AddComponent<Text>();
            lt.font = font;
            lt.text = "";
            lt.fontSize = 18;
            lt.color = new Color(0.8f, 0.1f, 0.1f);
            lt.alignment = TextAnchor.MiddleCenter;
            lt.fontStyle = FontStyle.Bold;
            racerLabels[i] = lt;

            int idx = i;
            b.onClick.AddListener(() => OnRacerClicked(idx));
        }

        // === 우하단 Start 버튼 ===
        GameObject startObj = new GameObject("StartBtn");
        startObj.transform.SetParent(parent, false);
        RectTransform srt = startObj.AddComponent<RectTransform>();
        srt.anchorMin = new Vector2(1, 0);
        srt.anchorMax = new Vector2(1, 0);
        srt.pivot = new Vector2(1, 0);
        srt.anchoredPosition = new Vector2(-30, 20);
        srt.sizeDelta = new Vector2(200, 65);

        startObj.AddComponent<Image>().color = new Color(0.95f, 0.85f, 0.15f);
        startButton = startObj.AddComponent<Button>();
        ColorBlock scb = startButton.colors;
        scb.normalColor = new Color(0.95f, 0.85f, 0.15f);
        scb.highlightedColor = new Color(1f, 0.95f, 0.4f);
        scb.pressedColor = new Color(0.8f, 0.7f, 0.1f);
        scb.disabledColor = new Color(0.5f, 0.5f, 0.5f);
        startButton.colors = scb;
        startButton.interactable = false;
        startButton.onClick.AddListener(OnStartClicked);

        MkText(startObj.transform, "Start",
            new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
            Vector2.zero, new Vector2(200, 65), 30, TextAnchor.MiddleCenter, Color.black);

        // === 우상단 정보 ===
        // 라운드 표시
        roundText = MkText(parent, "Round 1/7",
            new Vector2(1, 1), new Vector2(1, 1),
            new Vector2(-20, -10), new Vector2(250, 30), 22, TextAnchor.MiddleRight, Color.white);

        // 바퀴 표시
        lapText = MkText(parent, "이번 경기: 1바퀴",
            new Vector2(1, 1), new Vector2(1, 1),
            new Vector2(-20, -38), new Vector2(250, 25), 18, TextAnchor.MiddleRight, new Color(0.8f, 0.9f, 1f));

        // 총점 표시
        scoreText = MkText(parent, "총점: 0",
            new Vector2(1, 1), new Vector2(1, 1),
            new Vector2(-20, -62), new Vector2(250, 25), 20, TextAnchor.MiddleRight, Color.yellow);

        // ★ Top 100 버튼 (우하단, Start 위)
        GameObject top100Obj = new GameObject("Top100Btn");
        top100Obj.transform.SetParent(parent, false);
        RectTransform t100rt = top100Obj.AddComponent<RectTransform>();
        t100rt.anchorMin = new Vector2(1, 0);
        t100rt.anchorMax = new Vector2(1, 0);
        t100rt.pivot = new Vector2(1, 0);
        t100rt.anchoredPosition = new Vector2(-30, 95);
        t100rt.sizeDelta = new Vector2(200, 40);

        top100Obj.AddComponent<Image>().color = new Color(0.3f, 0.3f, 0.5f);
        Button top100Btn = top100Obj.AddComponent<Button>();
        ColorBlock t100cb = top100Btn.colors;
        t100cb.normalColor = new Color(0.3f, 0.3f, 0.5f);
        t100cb.highlightedColor = new Color(0.4f, 0.4f, 0.65f);
        t100cb.pressedColor = new Color(0.2f, 0.2f, 0.4f);
        top100Btn.colors = t100cb;
        top100Btn.onClick.AddListener(() => ShowLeaderboard());

        MkText(top100Obj.transform, "Top 100",
            new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
            Vector2.zero, new Vector2(200, 40), 20, TextAnchor.MiddleCenter, Color.white);
    }

    // ── 배팅 타입 탭 6개 ──
    private void BuildBetTypeTabs(Transform parent)
    {
        BetType[] types = { BetType.Win, BetType.Place, BetType.Quinella, BetType.Exacta, BetType.Trio, BetType.Wide };
        var gs = GameSettings.Instance;
        string[] labels = {
            "단승\n" + gs.payoutWin + "pt",
            "연승\n" + gs.payoutPlace + "pt",
            "복승\n" + gs.payoutQuinella + "pt",
            "쌍승\n" + gs.payoutExacta + "pt",
            "삼복승\n" + gs.payoutTrio + "pt",
            "복연승\n" + gs.payoutWide + "pt"
        };

        GameObject tabArea = new GameObject("TabArea");
        tabArea.transform.SetParent(parent, false);
        RectTransform tart = tabArea.AddComponent<RectTransform>();
        tart.anchorMin = new Vector2(0.02f, 0.93f);
        tart.anchorMax = new Vector2(0.98f, 1f);
        tart.offsetMin = Vector2.zero;
        tart.offsetMax = Vector2.zero;

        HorizontalLayoutGroup hlg = tabArea.AddComponent<HorizontalLayoutGroup>();
        hlg.spacing = 2;
        hlg.childForceExpandWidth = true;
        hlg.childForceExpandHeight = true;
        hlg.childControlWidth = true;
        hlg.childControlHeight = true;
        hlg.padding = new RectOffset(2, 2, 2, 0);

        betTypeBtns = new Button[types.Length];
        betTypeBtnTexts = new Text[types.Length];
        betTypeBtnBGs = new Image[types.Length];

        for (int i = 0; i < types.Length; i++)
        {
            GameObject tab = new GameObject("Tab_" + types[i]);
            tab.transform.SetParent(tabArea.transform, false);

            Image bg = tab.AddComponent<Image>();
            bg.color = new Color(0.85f, 0.75f, 0.1f);
            betTypeBtnBGs[i] = bg;

            Button b = tab.AddComponent<Button>();
            betTypeBtns[i] = b;

            Text t = MkText(tab.transform, labels[i],
                new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
                Vector2.zero, new Vector2(70, 60), 12, TextAnchor.MiddleCenter, Color.black);
            t.resizeTextForBestFit = true;
            t.resizeTextMinSize = 9;
            t.resizeTextMaxSize = 14;
            betTypeBtnTexts[i] = t;

            int idx = i;
            BetType bt = types[i];
            b.onClick.AddListener(() => OnBetTypeClicked(bt, idx));
        }

        // 기본: 쌍승 선택
        UpdateTabVisuals(3); // index 3 = Exacta
    }

    private void OnBetTypeClicked(BetType type, int tabIndex)
    {
        if (GameManager.Instance == null) return;
        currentTabType = type;
        GameManager.Instance.SelectBetType(type);
        UpdateTabVisuals(tabIndex);
        UpdateButtonVisuals();
        UpdateBettingArrows();
    }

    private void UpdateTabVisuals(int activeIndex)
    {
        Color activeColor = new Color(1f, 0.95f, 0.5f);
        Color inactiveColor = new Color(0.7f, 0.63f, 0.1f);

        for (int i = 0; i < betTypeBtnBGs.Length; i++)
        {
            betTypeBtnBGs[i].color = (i == activeIndex) ? activeColor : inactiveColor;
            betTypeBtnTexts[i].fontStyle = (i == activeIndex) ? FontStyle.Bold : FontStyle.Normal;
            betTypeBtnTexts[i].color = (i == activeIndex) ? Color.black : new Color(0.3f, 0.3f, 0.3f);
        }
    }

    // ── 레이싱 HUD ──
    private void BuildRacingUI(Transform parent)
    {
        // 좌측 순위 패널
        GameObject rankPanel = new GameObject("RankPanel");
        rankPanel.transform.SetParent(parent, false);
        RectTransform rrt = rankPanel.AddComponent<RectTransform>();
        rrt.anchorMin = new Vector2(0, 0.02f);
        rrt.anchorMax = new Vector2(0.22f, 0.98f);
        rrt.offsetMin = Vector2.zero;
        rrt.offsetMax = Vector2.zero;
        rankPanel.AddComponent<Image>().color = new Color(0, 0, 0, 0.65f);

        VerticalLayoutGroup rvlg = rankPanel.AddComponent<VerticalLayoutGroup>();
        rvlg.spacing = 1;
        rvlg.padding = new RectOffset(8, 8, 8, 8);
        rvlg.childForceExpandWidth = true;
        rvlg.childForceExpandHeight = true;
        rvlg.childControlWidth = true;
        rvlg.childControlHeight = true;

        rankTexts = new Text[GameConstants.RACER_COUNT];
        for (int i = 0; i < GameConstants.RACER_COUNT; i++)
        {
            GameObject ro = new GameObject("R" + i);
            ro.transform.SetParent(rankPanel.transform, false);
            Text rt = ro.AddComponent<Text>();
            rt.font = font;
            rt.fontSize = 16;
            rt.color = Color.white;
            rt.alignment = TextAnchor.MiddleLeft;
            rt.resizeTextForBestFit = true;
            rt.resizeTextMinSize = 10;
            rt.resizeTextMaxSize = 16;
            rankTexts[i] = rt;
        }

        // 내 배팅 표시 (상단 중앙)
        myBetText = MkText(parent, "",
            new Vector2(0.5f, 1), new Vector2(0.5f, 1),
            new Vector2(0, -10), new Vector2(600, 30), 20, TextAnchor.MiddleCenter, new Color(1f, 0.9f, 0.3f));

        // 라운드+바퀴 (상단 우측)
        racingRoundText = MkText(parent, "",
            new Vector2(1, 1), new Vector2(1, 1),
            new Vector2(-15, -10), new Vector2(250, 30), 20, TextAnchor.MiddleRight, new Color(0.8f, 0.9f, 1f));

        // 타이머
        raceTimerText = MkText(parent, "0.0초",
            new Vector2(1, 1), new Vector2(1, 1),
            new Vector2(-15, -38), new Vector2(130, 30), 22, TextAnchor.MiddleRight, Color.white);
    }

    // ── 결과 화면 ──
    private void BuildResultUI(Transform parent)
    {
        Image bg = parent.gameObject.AddComponent<Image>();
        bg.color = new Color(0, 0, 0, 0.75f);

        resultTitleText = MkText(parent, "레이스 결과",
            new Vector2(0.5f, 0.8f), new Vector2(0.5f, 0.8f),
            Vector2.zero, new Vector2(500, 60), 42, TextAnchor.MiddleCenter, new Color(1f, 0.85f, 0.2f));

        resultDetailText = MkText(parent, "",
            new Vector2(0.5f, 0.55f), new Vector2(0.5f, 0.55f),
            Vector2.zero, new Vector2(600, 200), 22, TextAnchor.MiddleCenter, Color.white);

        resultScoreText = MkText(parent, "",
            new Vector2(0.5f, 0.35f), new Vector2(0.5f, 0.35f),
            Vector2.zero, new Vector2(400, 50), 32, TextAnchor.MiddleCenter, Color.yellow);

        // 다음 라운드 버튼
        GameObject nb = new GameObject("NextBtn");
        nb.transform.SetParent(parent, false);
        RectTransform nrt = nb.AddComponent<RectTransform>();
        nrt.anchorMin = new Vector2(0.5f, 0.15f);
        nrt.anchorMax = new Vector2(0.5f, 0.15f);
        nrt.pivot = new Vector2(0.5f, 0.5f);
        nrt.sizeDelta = new Vector2(250, 60);

        nb.AddComponent<Image>().color = new Color(0.25f, 0.5f, 0.9f);
        nextRoundButton = nb.AddComponent<Button>();
        nextRoundButton.onClick.AddListener(() => GameManager.Instance?.NextRound());

        nextRoundBtnText = MkText(nb.transform, "다음 라운드",
            new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
            Vector2.zero, new Vector2(250, 60), 26, TextAnchor.MiddleCenter, Color.white);
    }

    // ══════════════════════════════════════
    //  배팅 로직 (★ 전면 교체)
    // ══════════════════════════════════════
    private void OnRacerClicked(int index)
    {
        if (GameManager.Instance == null) return;
        var bet = GameManager.Instance.CurrentBet;
        if (bet == null) return;

        // 이미 선택된 레이서 클릭 → 제거
        if (bet.selections.Contains(index))
        {
            GameManager.Instance.RemoveSelection(index);
        }
        else
        {
            // 이미 완료된 상태에서 추가 클릭 → 리셋 후 새로 선택
            if (bet.IsComplete)
            {
                GameManager.Instance.SelectBetType(bet.type);
                GameManager.Instance.AddSelection(index);
            }
            else
            {
                GameManager.Instance.AddSelection(index);
            }
        }

        UpdateButtonVisuals();
        UpdateBettingArrows();
    }

    /// <summary>
    /// 배팅 선택 시 캐릭터 위 화살표+정보 즉시 표시
    /// </summary>
    private void UpdateBettingArrows()
    {
        DestroyArrows();
        HideAllRaceLabels();
        if (RaceManager.Instance == null || GameManager.Instance == null) return;
        var racers = RaceManager.Instance.Racers;
        var bet = GameManager.Instance.CurrentBet;
        if (bet == null || bet.selections.Count == 0) return;

        Color[] arrowColors = { Color.red, new Color(0.3f, 0.6f, 1f), new Color(0.2f, 0.8f, 0.2f) };

        for (int i = 0; i < bet.selections.Count; i++)
        {
            int sel = bet.selections[i];
            if (sel >= 0 && sel < racers.Count)
            {
                string selLabel = bet.GetSelectionLabel(i);
                string racerName = GameConstants.RACER_NAMES[sel];
                string arrowLabel = selLabel + ":" + racerName;
                Color c = arrowColors[Mathf.Min(i, arrowColors.Length - 1)];
                GameObject arrow = MakeArrow(racers[sel].transform, arrowLabel, c);
                betArrows.Add(arrow);
            }
        }
    }

    private void UpdateButtonVisuals()
    {
        var gm = GameManager.Instance;
        if (gm == null) return;
        var bet = gm.CurrentBet;
        if (bet == null) return;

        // 선택 색상
        Color[] selColors = {
            new Color(1f, 0.7f, 0.7f),     // 첫 번째 선택
            new Color(0.7f, 0.7f, 1f),     // 두 번째
            new Color(0.7f, 1f, 0.7f),     // 세 번째
        };

        for (int i = 0; i < GameConstants.RACER_COUNT; i++)
        {
            int selIdx = bet.selections.IndexOf(i);
            if (selIdx >= 0)
            {
                racerBGs[i].color = selColors[Mathf.Min(selIdx, selColors.Length - 1)];
                racerLabels[i].text = bet.GetSelectionLabel(selIdx);
                racerLabels[i].color = selIdx == 0 ? Color.red : selIdx == 1 ? Color.blue : new Color(0, 0.6f, 0);
            }
            else
            {
                racerBGs[i].color = Color.white;
                racerLabels[i].text = "";
            }
        }

        // Start 버튼 활성화
        startButton.interactable = bet.IsComplete;

        // 안내 텍스트
        if (infoText != null)
            infoText.text = bet.GetSelectionGuide();

        // 타이틀에 배팅 타입 표시
        if (titleText != null)
            titleText.text = BettingCalculator.GetTypeName(bet.type) + " 배팅";
    }

    private void OnStartClicked()
    {
        GameManager.Instance?.StartRace();
    }

    // ══════════════════════════════════════
    //  상태 전환
    // ══════════════════════════════════════
    private void OnStateChanged(GameManager.GameState state)
    {
        bettingUI.SetActive(false);
        racingUI.SetActive(false);
        resultUI.SetActive(false);
        countdownUI.SetActive(false);
        finishUI.SetActive(false);

        switch (state)
        {
            case GameManager.GameState.Betting:
                bettingUI.SetActive(true);
                ResetBetting();
                UpdateRoundInfo();
                UpdateScore();
                break;
            case GameManager.GameState.Countdown:
                // ★ 화살표 유지, 번호 숨김 유지
                countdownUI.SetActive(true);
                HideAllRaceLabels();
                break;
            case GameManager.GameState.Racing:
                racingUI.SetActive(true);
                raceTimer = 0f;
                UpdateMyBet();
                UpdateRacingRoundInfo();
                HideAllRaceLabels();
                // ★ 화살표 이미 배팅 시 생성됨 → 유지
                break;
            case GameManager.GameState.Result:
                DestroyArrows();
                ShowAllRaceLabels();
                resultUI.SetActive(true);
                ShowResult();
                break;
            case GameManager.GameState.Finish:
                DestroyArrows();
                ShowAllRaceLabels();
                finishUI.SetActive(true);
                ShowFinish();
                break;
        }
    }

    private void OnCountdownTick(int t)
    {
        if (countdownText != null)
            countdownText.text = t > 0 ? t.ToString() : "GO!";
    }

    private void ResetBetting()
    {
        // 탭 비주얼 복원 (현재 타입에 맞게)
        BetType[] types = { BetType.Win, BetType.Place, BetType.Quinella, BetType.Exacta, BetType.Trio, BetType.Wide };
        for (int i = 0; i < types.Length; i++)
        {
            if (types[i] == currentTabType)
            {
                UpdateTabVisuals(i);
                break;
            }
        }
        HideAllRaceLabels();
        DestroyArrows();
        UpdateButtonVisuals();
    }

    private void UpdateRoundInfo()
    {
        var gm = GameManager.Instance;
        if (gm == null) return;

        if (roundText != null)
            roundText.text = "Round " + gm.CurrentRound + "/" + gm.TotalRounds;
        if (lapText != null)
            lapText.text = "이번 경기: " + gm.CurrentRoundLaps + "바퀴";
    }

    private void UpdateRacingRoundInfo()
    {
        var gm = GameManager.Instance;
        if (gm == null) return;
        if (racingRoundText != null)
            racingRoundText.text = "Round " + gm.CurrentRound + "/" + gm.TotalRounds + "  |  " + gm.CurrentRoundLaps + "바퀴";
    }

    private void UpdateScore()
    {
        if (scoreText != null && ScoreManager.Instance != null)
            scoreText.text = "총점: " + ScoreManager.Instance.TotalScore;
    }

    private void UpdateMyBet()
    {
        if (myBetText == null || GameManager.Instance == null) return;
        var bet = GameManager.Instance.CurrentBet;
        if (bet == null) return;

        string typeName = BettingCalculator.GetTypeName(bet.type);
        string names = "";
        for (int i = 0; i < bet.selections.Count; i++)
        {
            if (i > 0) names += ", ";
            names += bet.GetSelectionLabel(i) + ":" + GameConstants.RACER_NAMES[bet.selections[i]];
        }
        myBetText.text = "내 배팅 ▶ " + typeName + " | " + names;
    }

    private void UpdateLiveRankings()
    {
        if (RaceManager.Instance == null || rankTexts == null) return;
        var live = RaceManager.Instance.GetLiveRankings();
        var bet = GameManager.Instance?.CurrentBet;
        int totalLaps = RaceManager.Instance.CurrentLaps;
        HashSet<int> myPicks = new HashSet<int>();
        if (bet != null)
            foreach (int s in bet.selections)
                myPicks.Add(s);

        for (int i = 0; i < rankTexts.Length && i < live.Count; i++)
        {
            var r = live[i];
            string mark = myPicks.Contains(r.RacerIndex) ? " ★" : "";
            string lapInfo = r.IsFinished ? "완주" : "[" + r.CurrentLap + "/" + totalLaps + "바퀴]";
            string spd = r.IsFinished ? "" : " x" + r.CurrentSpeed.ToString("F1");
            rankTexts[i].text = (i + 1) + "위 " + GameConstants.RACER_NAMES[r.RacerIndex] + " " + lapInfo + spd + mark;
            rankTexts[i].color = myPicks.Contains(r.RacerIndex) ? new Color(1f, 0.9f, 0.3f) : Color.white;
        }
    }

    private void ShowResult()
    {
        var rankings = RaceManager.Instance?.GetFinalRankings();
        if (rankings == null || rankings.Count < 3) return;

        var gm = GameManager.Instance;
        var bet = gm?.CurrentBet;
        int score = ScoreManager.Instance?.LastRoundScore ?? 0;

        // 타이틀
        resultTitleText.text = score > 0 ? "적중!" : "아쉽네요...";
        resultTitleText.color = score > 0 ? new Color(1f, 0.85f, 0.2f) : new Color(0.7f, 0.7f, 0.7f);

        // 상세
        string detail = "";
        detail += "1등: " + rankings[0].racerName + "  /  2등: " + rankings[1].racerName + "  /  3등: " + rankings[2].racerName + "\n\n";

        if (bet != null)
        {
            string typeName = BettingCalculator.GetTypeName(bet.type);
            detail += "배팅: " + typeName + " (" + BettingCalculator.GetTypeDesc(bet.type) + ")\n";

            // 내 선택 → 실제 결과
            for (int i = 0; i < bet.selections.Count; i++)
            {
                int sel = bet.selections[i];
                string selName = GameConstants.RACER_NAMES[sel];
                string label = bet.GetSelectionLabel(i);

                // 실제 순위 찾기
                int actualRank = -1;
                for (int r = 0; r < rankings.Count; r++)
                {
                    if (rankings[r].racerIndex == sel) { actualRank = r + 1; break; }
                }
                detail += "내 " + label + " 예측: " + selName + " → 실제 " + actualRank + "등\n";
            }
        }

        resultDetailText.text = detail;

        // 점수
        int totalScore = ScoreManager.Instance?.TotalScore ?? 0;
        resultScoreText.text = score > 0
            ? "+" + score + "점 획득!  (총점: " + totalScore + ")"
            : "0점  (총점: " + totalScore + ")";
        resultScoreText.color = score > 0 ? Color.yellow : new Color(0.7f, 0.7f, 0.7f);

        // 버튼 텍스트
        if (nextRoundBtnText != null)
        {
            if (gm != null && gm.IsLastRound)
                nextRoundBtnText.text = "새 게임";
            else
                nextRoundBtnText.text = "다음 라운드";
        }
    }

    // ══════════════════════════════════════
    //  Finish 화면 (★ STEP5)
    // ══════════════════════════════════════
    private void BuildFinishUI(Transform parent)
    {
        Image bg = parent.gameObject.AddComponent<Image>();
        bg.color = new Color(0, 0, 0, 0.85f);

        // 타이틀
        finishTitleText = MkText(parent, "Finish!!",
            new Vector2(0.5f, 0.92f), new Vector2(0.5f, 0.92f),
            Vector2.zero, new Vector2(500, 70), 55, TextAnchor.MiddleCenter, new Color(1f, 0.85f, 0.2f));

        // 라운드별 결과 테이블
        finishRoundDetailText = MkText(parent, "",
            new Vector2(0.5f, 0.58f), new Vector2(0.5f, 0.58f),
            Vector2.zero, new Vector2(700, 400), 20, TextAnchor.UpperCenter, Color.white);
        finishRoundDetailText.verticalOverflow = VerticalWrapMode.Overflow;

        // 총점
        finishTotalScoreText = MkText(parent, "",
            new Vector2(0.5f, 0.18f), new Vector2(0.5f, 0.18f),
            Vector2.zero, new Vector2(500, 60), 38, TextAnchor.MiddleCenter, Color.yellow);

        // 새 게임 버튼
        GameObject newGameBtn = new GameObject("NewGameBtn");
        newGameBtn.transform.SetParent(parent, false);
        RectTransform ngrt = newGameBtn.AddComponent<RectTransform>();
        ngrt.anchorMin = new Vector2(0.3f, 0.05f);
        ngrt.anchorMax = new Vector2(0.3f, 0.05f);
        ngrt.pivot = new Vector2(0.5f, 0.5f);
        ngrt.sizeDelta = new Vector2(220, 55);

        newGameBtn.AddComponent<Image>().color = new Color(0.25f, 0.5f, 0.9f);
        Button ngb = newGameBtn.AddComponent<Button>();
        ngb.onClick.AddListener(() =>
        {
            RaceManager.Instance?.ResetRace();
            GameManager.Instance?.StartNewGame();
        });
        MkText(newGameBtn.transform, "새 게임",
            new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
            Vector2.zero, new Vector2(220, 55), 26, TextAnchor.MiddleCenter, Color.white);

        // Top 100 버튼
        GameObject top100Btn = new GameObject("Top100Btn");
        top100Btn.transform.SetParent(parent, false);
        RectTransform t100rt = top100Btn.AddComponent<RectTransform>();
        t100rt.anchorMin = new Vector2(0.7f, 0.05f);
        t100rt.anchorMax = new Vector2(0.7f, 0.05f);
        t100rt.pivot = new Vector2(0.5f, 0.5f);
        t100rt.sizeDelta = new Vector2(220, 55);

        top100Btn.AddComponent<Image>().color = new Color(0.5f, 0.3f, 0.6f);
        Button t100b = top100Btn.AddComponent<Button>();
        t100b.onClick.AddListener(() => ShowLeaderboard());
        MkText(top100Btn.transform, "Top 100",
            new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
            Vector2.zero, new Vector2(220, 55), 26, TextAnchor.MiddleCenter, Color.white);
    }

    private void ShowFinish()
    {
        var sm = ScoreManager.Instance;
        if (sm == null) return;

        // 라운드별 결과 테이블
        string detail = "<b>라운드별 결과</b>\n";
        detail += "─────────────────────────\n";
        foreach (var r in sm.RoundHistory)
        {
            string typeName = BettingCalculator.GetTypeName(r.betType);
            string scoreStr = r.score > 0 ? "<color=#FFD700>+" + r.score + "점</color>" : "<color=#888888>+0점</color>";
            string result = r.isWin ? "<color=#66FF66>적중!</color>" : "<color=#FF6666>실패</color>";
            detail += "R" + r.round + "  |  " + typeName + "  |  " + result + "  " + scoreStr + "\n";
        }
        detail += "─────────────────────────";

        finishRoundDetailText.text = detail;

        // 총점
        int total = sm.CurrentGameScore;
        int wins = 0;
        foreach (var r in sm.RoundHistory)
            if (r.isWin) wins++;

        finishTotalScoreText.text = "총점: " + total + "점  (" + wins + "/" + sm.RoundHistory.Count + " 적중)";
    }

    // ══════════════════════════════════════
    //  리더보드 팝업 (★ STEP5)
    // ══════════════════════════════════════
    private void BuildLeaderboardPopup(Transform parent)
    {
        Image bg = parent.gameObject.AddComponent<Image>();
        bg.color = new Color(0, 0, 0, 0.9f);

        // 타이틀
        leaderboardTitleText = MkText(parent, "Top 100 리더보드",
            new Vector2(0.5f, 0.95f), new Vector2(0.5f, 0.95f),
            Vector2.zero, new Vector2(500, 50), 34, TextAnchor.MiddleCenter, new Color(1f, 0.85f, 0.2f));

        // 헤더
        MkText(parent, "<b>순위    점수    적중    날짜              요약</b>",
            new Vector2(0.5f, 0.89f), new Vector2(0.5f, 0.89f),
            Vector2.zero, new Vector2(800, 30), 16, TextAnchor.MiddleCenter, new Color(0.8f, 0.8f, 0.8f));

        // 스크롤 영역 (간단히 Text로)
        leaderboardContentText = MkText(parent, "",
            new Vector2(0.5f, 0.52f), new Vector2(0.5f, 0.52f),
            Vector2.zero, new Vector2(800, 600), 15, TextAnchor.UpperCenter, Color.white);
        leaderboardContentText.verticalOverflow = VerticalWrapMode.Overflow;

        // 닫기 버튼
        GameObject closeBtn = new GameObject("CloseBtn");
        closeBtn.transform.SetParent(parent, false);
        RectTransform crt = closeBtn.AddComponent<RectTransform>();
        crt.anchorMin = new Vector2(0.5f, 0.03f);
        crt.anchorMax = new Vector2(0.5f, 0.03f);
        crt.pivot = new Vector2(0.5f, 0.5f);
        crt.sizeDelta = new Vector2(200, 50);

        closeBtn.AddComponent<Image>().color = new Color(0.5f, 0.3f, 0.3f);
        Button cb = closeBtn.AddComponent<Button>();
        cb.onClick.AddListener(() => leaderboardPopup.SetActive(false));
        MkText(closeBtn.transform, "닫기",
            new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
            Vector2.zero, new Vector2(200, 50), 24, TextAnchor.MiddleCenter, Color.white);
    }

    private void ShowLeaderboard()
    {
        var entries = LeaderboardData.GetTop(100);
        string content = "";

        if (entries.Count == 0)
        {
            content = "\n\n\n기록이 없습니다.\n게임을 완료하면 자동으로 기록됩니다.";
        }
        else
        {
            for (int i = 0; i < entries.Count; i++)
            {
                var e = entries[i];
                string rank = (i + 1).ToString().PadLeft(3);
                string score = e.score.ToString().PadLeft(6);
                string rounds = e.rounds + "R";
                string date = e.date;

                // 요약을 간략하게
                string summary = e.summary;
                if (summary.Length > 40) summary = summary.Substring(0, 40) + "...";

                bool isGold = i < 3;
                string line = rank + "위  " + score + "점  " + rounds + "  " + date + "  " + summary;

                if (isGold)
                    content += "<color=#FFD700>" + line + "</color>\n";
                else
                    content += line + "\n";
            }
        }

        leaderboardContentText.text = content;
        leaderboardPopup.SetActive(true);
    }

    // ══════════════════════════════════════
    //  캐릭터 라벨 관리
    // ══════════════════════════════════════
    private void HideAllRaceLabels()
    {
        if (RaceManager.Instance == null) return;
        foreach (var r in RaceManager.Instance.Racers)
        {
            Transform lb = r.transform.Find("RaceLabel");
            if (lb != null) lb.gameObject.SetActive(false);
        }
    }

    private void ShowAllRaceLabels()
    {
        if (RaceManager.Instance == null) return;
        foreach (var r in RaceManager.Instance.Racers)
        {
            Transform lb = r.transform.Find("RaceLabel");
            if (lb != null) lb.gameObject.SetActive(true);
        }
    }

    // ══════════════════════════════════════
    //  선택 캐릭터 화살표 (다중 지원)
    // ══════════════════════════════════════
    private GameObject MakeArrow(Transform parent, string label, Color color)
    {
        GameObject obj = new GameObject("Arrow");
        obj.transform.SetParent(parent);
        obj.transform.localPosition = new Vector3(0, GameSettings.Instance.labelHeight + GameSettings.Instance.betMarkerHeight, 0);
        obj.transform.localScale = Vector3.one;

        TextMesh tm = obj.AddComponent<TextMesh>();
        tm.text = label + "\n▼";
        tm.alignment = TextAlignment.Center;
        tm.anchor = TextAnchor.LowerCenter;
        tm.characterSize = GameSettings.Instance.betMarkerSize;
        tm.fontSize = 48;
        tm.fontStyle = FontStyle.Bold;
        tm.color = color;
        obj.GetComponent<MeshRenderer>().sortingOrder = 50;

        return obj;
    }

    private void DestroyArrows()
    {
        foreach (var arrow in betArrows)
        {
            if (arrow != null)
                Destroy(arrow);
        }
        betArrows.Clear();
    }

    private void UpdateArrowPositions()
    {
        var s = GameSettings.Instance;
        float bounce = Mathf.Sin(Time.time * 4f) * 0.08f;
        float h = s.labelHeight + s.betMarkerHeight;

        foreach (var arrow in betArrows)
        {
            if (arrow != null)
            {
                arrow.transform.localPosition = new Vector3(0, h + bounce, 0);
                TextMesh tm = arrow.GetComponent<TextMesh>();
                if (tm != null) tm.characterSize = s.betMarkerSize;
            }
        }
    }

    // ══════════════════════════════════════
    //  유틸리티
    // ══════════════════════════════════════
    private RectTransform AddFullRect(GameObject obj)
    {
        RectTransform rt = obj.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        return rt;
    }

    private Text MkText(Transform parent, string text,
        Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size,
        int fontSize, TextAnchor align, Color? color = null)
    {
        GameObject o = new GameObject("T");
        o.transform.SetParent(parent, false);
        RectTransform rt = o.AddComponent<RectTransform>();
        rt.anchorMin = anchor; rt.anchorMax = anchor; rt.pivot = pivot;
        rt.anchoredPosition = pos; rt.sizeDelta = size;

        Text t = o.AddComponent<Text>();
        t.font = font; t.text = text; t.fontSize = fontSize;
        t.alignment = align; t.color = color ?? Color.white;
        t.horizontalOverflow = HorizontalWrapMode.Overflow;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.supportRichText = true;
        return t;
    }
}