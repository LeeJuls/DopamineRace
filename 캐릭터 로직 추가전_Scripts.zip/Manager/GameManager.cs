using UnityEngine;
using System;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }
    public enum GameState { Betting, Countdown, Racing, Result, Finish }
    public GameState CurrentState { get; private set; } = GameState.Betting;

    public event Action<GameState> OnStateChanged;
    public event Action<int> OnCountdownTick;
    public event Action OnRaceStart;
    public event Action<int> OnRoundChanged;          // ★ 라운드 변경 알림

    private float countdownTimer;

    // ═══ 기존 호환 (쌍승 전용) ═══
    public int BetFirst { get; private set; } = -1;
    public int BetSecond { get; private set; } = -1;

    // ═══ 라운드 시스템 ═══
    public int CurrentRound { get; private set; } = 1;      // 1-based
    public int TotalRounds => GameSettings.Instance.TotalRounds;
    public int CurrentRoundLaps => GameSettings.Instance.GetLapsForRound(CurrentRound);
    public bool IsLastRound => CurrentRound >= TotalRounds;

    // ═══ 배팅 시스템 ═══
    public BetInfo CurrentBet { get; private set; }

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    private void Start()
    {
        StartNewGame();
    }

    private void Update()
    {
        if (CurrentState == GameState.Countdown)
        {
            countdownTimer -= Time.deltaTime;
            OnCountdownTick?.Invoke(Mathf.CeilToInt(countdownTimer));
            if (countdownTimer <= 0f) ChangeState(GameState.Racing);
        }
    }

    // ═══ 게임 초기화 (새 게임 시작) ═══
    public void StartNewGame()
    {
        CurrentRound = 1;
        CurrentBet = new BetInfo(BetType.Exacta);   // 기본 = 쌍승
        ScoreManager.Instance?.ResetAll();
        ApplyRoundLaps();
        Debug.Log("═══ 새 게임 시작 | 총 " + TotalRounds + " 라운드 ═══");
        ChangeState(GameState.Betting);
    }

    // ═══ 배팅 타입 선택 ═══
    public void SelectBetType(BetType type)
    {
        if (CurrentState != GameState.Betting) return;
        CurrentBet = new BetInfo(type);
        BetFirst = -1;
        BetSecond = -1;
        Debug.Log("[배팅] 타입 변경: " + BettingCalculator.GetTypeName(type)
            + " (" + BettingCalculator.GetTypeDesc(type) + ") → "
            + BettingCalculator.GetPayout(type) + "점");
    }

    // ═══ 선택 추가 ═══
    public void AddSelection(int racerIndex)
    {
        if (CurrentState != GameState.Betting) return;
        if (CurrentBet == null) return;
        if (CurrentBet.IsComplete) return;
        if (CurrentBet.selections.Contains(racerIndex)) return;

        CurrentBet.selections.Add(racerIndex);
        Debug.Log("[배팅] 선택 추가: " + GameConstants.RACER_NAMES[racerIndex]
            + " (" + CurrentBet.selections.Count + "/" + CurrentBet.RequiredSelections + ")");

        // 기존 호환: BetFirst / BetSecond 동기화
        SyncLegacyBets();
    }

    // ═══ 선택 제거 ═══
    public void RemoveSelection(int racerIndex)
    {
        if (CurrentState != GameState.Betting) return;
        if (CurrentBet == null) return;

        int idx = CurrentBet.selections.IndexOf(racerIndex);
        if (idx >= 0)
        {
            CurrentBet.selections.RemoveAt(idx);
            Debug.Log("[배팅] 선택 제거: " + GameConstants.RACER_NAMES[racerIndex]
                + " (" + CurrentBet.selections.Count + "/" + CurrentBet.RequiredSelections + ")");
            SyncLegacyBets();
        }
    }

    // 기존 BetFirst/BetSecond와 동기화
    private void SyncLegacyBets()
    {
        BetFirst = CurrentBet.selections.Count > 0 ? CurrentBet.selections[0] : -1;
        BetSecond = CurrentBet.selections.Count > 1 ? CurrentBet.selections[1] : -1;
    }

    // ═══ 상태 변경 ═══
    public void ChangeState(GameState s)
    {
        CurrentState = s;
        if (s == GameState.Betting)
        {
            // 배팅 타입은 유지, 선택만 리셋
            if (CurrentBet != null)
                CurrentBet.selections.Clear();
            BetFirst = -1;
            BetSecond = -1;
        }
        if (s == GameState.Countdown) countdownTimer = 3f;
        if (s == GameState.Racing) OnRaceStart?.Invoke();
        if (s == GameState.Result) CalcScore();
        if (s == GameState.Finish) ScoreManager.Instance?.SaveToLeaderboard();
        OnStateChanged?.Invoke(s);
    }

    // ═══ 기존 호환: PlaceBet ═══
    public void PlaceBet(int first, int second)
    {
        BetFirst = first;
        BetSecond = second;
        // BetInfo에도 반영
        if (CurrentBet != null)
        {
            CurrentBet.selections.Clear();
            CurrentBet.selections.Add(first);
            if (CurrentBet.RequiredSelections > 1)
                CurrentBet.selections.Add(second);
        }
    }

    // ═══ 레이스 시작 ═══
    public void StartRace()
    {
        if (CurrentBet == null || !CurrentBet.IsComplete) return;
        Debug.Log("═══ Round " + CurrentRound + "/" + TotalRounds
            + " | " + CurrentRoundLaps + "바퀴 | "
            + BettingCalculator.GetTypeName(CurrentBet.type) + " 배팅 ═══");
        ChangeState(GameState.Countdown);
    }

    // ═══ 점수 계산 ═══
    private void CalcScore()
    {
        var rankings = RaceManager.Instance?.GetFinalRankings();
        if (rankings == null || rankings.Count < 3) return;

        // 인덱스 리스트 (0=1등, 1=2등, 2=3등...)
        List<int> rankingIndices = new List<int>();
        foreach (var r in rankings)
            rankingIndices.Add(r.racerIndex);

        int score = BettingCalculator.Calculate(CurrentBet, rankingIndices);

        Debug.Log("[결과] Round " + CurrentRound + " | "
            + BettingCalculator.GetTypeName(CurrentBet.type) + " → "
            + (score > 0 ? "적중! +" + score + "점" : "실패 +0점"));

        // ScoreManager에 라운드 결과 기록
        ScoreManager.Instance?.RecordRound(CurrentBet.type, score);
    }

    // ═══ 다음 라운드 ═══
    public void NextRound()
    {
        if (IsLastRound)
        {
            // 마지막 라운드 → Finish 화면
            Debug.Log("═══ 전체 " + TotalRounds + " 라운드 종료! 총점: "
                + ScoreManager.Instance?.CurrentGameScore + " ═══");
            ChangeState(GameState.Finish);
            return;
        }

        CurrentRound++;
        ApplyRoundLaps();
        RaceManager.Instance?.ResetRace();

        Debug.Log("═══ Next → Round " + CurrentRound + "/" + TotalRounds
            + " | " + CurrentRoundLaps + "바퀴 ═══");

        OnRoundChanged?.Invoke(CurrentRound);
        ChangeState(GameState.Betting);
    }

    // 현재 라운드의 바퀴 수를 RaceManager에 적용
    private void ApplyRoundLaps()
    {
        int laps = CurrentRoundLaps;
        RaceManager.Instance?.SetLaps(laps);
        Debug.Log("[라운드] Round " + CurrentRound + ", Laps: " + laps);
    }
}