using UnityEngine;

/// <summary>
/// 게임 세팅 데이터 (Unity Inspector에서 편집 가능)
/// </summary>
[CreateAssetMenu(fileName = "GameSettings", menuName = "DopamineRace/GameSettings")]
public class GameSettings : ScriptableObject
{
    [Header("═══ 레이서 설정 ═══")]
    [Tooltip("한 레이스당 참가 레이서 수 (2~12)")]
    [Range(2, 12)]
    public int racerCount = 8;

    [Header("═══ 속도 설정 ═══")]
    [Tooltip("최소 속도")]
    public float racerMinSpeed = 1.0f;

    [Tooltip("최대 속도")]
    public float racerMaxSpeed = 4.0f;

    [Tooltip("속도 변경 간격 (초)")]
    public float speedChangeInterval = 3f;

    [Tooltip("속도 보간 속도")]
    public float speedLerpRate = 3f;

    [Header("═══ 라운드 설정 ═══")]
    [Tooltip("라운드별 바퀴 수 (배열 길이 = 총 라운드 수)\n예: [1,2,1,5,3,1,4] → 7라운드")]
    public int[] roundLaps = new int[] { 1, 2, 1, 5, 3, 1, 4 };

    /// <summary>
    /// 총 라운드 수 (roundLaps 배열 길이)
    /// </summary>
    public int TotalRounds => (roundLaps != null && roundLaps.Length > 0) ? roundLaps.Length : 1;

    /// <summary>
    /// 해당 라운드의 바퀴 수 (1-based round 번호)
    /// </summary>
    public int GetLapsForRound(int round)
    {
        if (roundLaps == null || roundLaps.Length == 0) return 1;
        int idx = Mathf.Clamp(round - 1, 0, roundLaps.Length - 1);
        return Mathf.Max(1, roundLaps[idx]);
    }

    [Header("═══ 배당 점수 설정 ═══")]
    [Tooltip("단승 배당 (1등 맞추기)")]
    public int payoutWin = 3;

    [Tooltip("연승 배당 (3착 이내 1마리, 7두 이하 시 2착)")]
    public int payoutPlace = 1;

    [Tooltip("복승 배당 (1~2등 2마리, 순서 무관)")]
    public int payoutQuinella = 4;

    [Tooltip("쌍승 배당 (1등+2등 정확한 순서)")]
    public int payoutExacta = 6;

    [Tooltip("삼복승 배당 (1~3등 3마리, 순서 무관)")]
    public int payoutTrio = 10;

    [Tooltip("복연승 배당 (3착 이내 2마리, 순서 무관)")]
    public int payoutWide = 2;

    [Header("═══ 경로 설정 ═══")]
    [Tooltip("경로 이탈 가중치\n0 = 정확히 트랙 위\n0.1~0.3 = 약간 흔들림")]
    [Range(0f, 1f)]
    public float pathDeviation = 0f;

    [Header("═══ 캐릭터 표시 설정 ═══")]
    [Tooltip("캐릭터 크기")]
    public float characterScale = 0.8f;

    [Tooltip("레인 오프셋")]
    public float laneOffset = 0.05f;

    [Tooltip("번호 라벨 크기")]
    public float labelSize = 0.2f;

    [Tooltip("번호 라벨 높이")]
    public float labelHeight = 1.5f;

    [Tooltip("배팅 마커 크기")]
    public float betMarkerSize = 0.05f;

    [Tooltip("배팅 마커 높이")]
    public float betMarkerHeight = 0.3f;

    // ═══ 기존 호환 ═══
    public int firstPlaceScore => payoutExacta;
    public int secondPlaceScore => payoutPlace;

    // ═══ 싱글톤 로드 ═══
    private static GameSettings _instance;
    public static GameSettings Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = Resources.Load<GameSettings>("GameSettings");
                if (_instance == null)
                {
                    Debug.LogWarning("GameSettings 에셋을 찾을 수 없습니다! 기본값을 사용합니다.");
                    _instance = CreateInstance<GameSettings>();
                }
            }
            return _instance;
        }
    }

    // ═══ 리더보드 관리 (Inspector 우클릭 메뉴) ═══
    [ContextMenu("리더보드 초기화 (Top 100 삭제)")]
    private void ClearLeaderboard()
    {
        LeaderboardData.Clear();
        Debug.Log("★ 리더보드 전체 초기화 완료!");
    }

    [ContextMenu("리더보드 확인 (Console 출력)")]
    private void PrintLeaderboard()
    {
        var entries = LeaderboardData.GetTop(10);
        Debug.Log("★ 리더보드 상위 " + entries.Count + "개:");
        for (int i = 0; i < entries.Count; i++)
        {
            var e = entries[i];
            Debug.Log("  " + (i + 1) + "위: " + e.score + "점 (" + e.rounds + "R) " + e.date + " | " + e.summary);
        }
    }
}