using UnityEngine;

/// <summary>
/// 기존 코드 호환용 래퍼.
/// 모든 값은 GameSettings에서 가져옴.
/// 새 코드에서는 GameSettings.Instance를 직접 사용해도 됨.
/// </summary>
public static class GameConstants
{
    private static GameSettings S => GameSettings.Instance;

    public static int RACER_COUNT => S.racerCount;
    public static float RACER_MIN_SPEED => S.racerMinSpeed;
    public static float RACER_MAX_SPEED => S.racerMaxSpeed;
    public static float SPEED_CHANGE_INTERVAL => S.speedChangeInterval;
    public static float SPEED_LERP_RATE => S.speedLerpRate;
    public static int TOTAL_LAPS => S.GetLapsForRound(1);  // fallback: 1라운드 바퀴 수
    public static int FIRST_PLACE_SCORE => S.firstPlaceScore;
    public static int SECOND_PLACE_SCORE => S.secondPlaceScore;

    public static string[] RACER_NAMES => S.racerNames;
    public static Color[] RACER_COLORS => S.racerColors;

    // 이전 코드 호환 (더 이상 사용 안 함)
    public const int WAYPOINT_COUNT = 24;
    public const float TRACK_RADIUS_X = 5.8f;
    public const float TRACK_RADIUS_Y = 2.5f;
}