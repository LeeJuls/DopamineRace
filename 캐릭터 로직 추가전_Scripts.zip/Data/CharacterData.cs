using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// 캐릭터 타입 (경주 스타일)
/// </summary>
public enum CharacterType
{
    Runner,     // 도주: 초반 전력질주
    Leader,     // 선행: 앞쪽에서 안정적으로
    Chaser,     // 선입: 중반부터 치고 올라옴
    Reckoner,   // 추입: 후반 폭발
}

/// <summary>
/// 캐릭터 1명의 전체 데이터 (CSV 1행)
/// </summary>
[System.Serializable]
public class CharacterData
{
    public string charName;             // 이름
    public float charBaseSpeed;         // 기본 속도 배율
    public float charBasePower;         // 충돌 강도 (미래 기능)
    public float charBaseBrave;         // 충돌 의지
    public float charBaseCalm;          // 안정성 (순위 밀릴 때 멘탈)
    public float charBaseEndurance;     // 지구력 (장거리 스태미나)
    public CharacterType charType;      // 경주 스타일
    public string charAbility;          // 능력 설명 텍스트
    public string charResourcePrefabs;  // 프리팹 경로
    public string charIcon;             // 아이콘 경로 (128x128 PNG)

    /// <summary>
    /// 프리팹 로드 (Resources 기준)
    /// </summary>
    public GameObject LoadPrefab()
    {
        if (string.IsNullOrEmpty(charResourcePrefabs)) return null;
        // CSV 경로에서 Resources/ 이후 부분만 추출, 확장자 제거
        string path = charResourcePrefabs;
        if (path.Contains("Resources\\"))
            path = path.Substring(path.IndexOf("Resources\\") + 10);
        if (path.Contains("Resources/"))
            path = path.Substring(path.IndexOf("Resources/") + 10);
        if (path.EndsWith(".prefab"))
            path = path.Substring(0, path.Length - 7);
        return Resources.Load<GameObject>(path);
    }

    /// <summary>
    /// 아이콘 로드 (Resources 기준)
    /// </summary>
    public Sprite LoadIcon()
    {
        if (string.IsNullOrEmpty(charIcon)) return null;
        string path = charIcon;
        if (path.EndsWith(".png"))
            path = path.Substring(0, path.Length - 4);
        return Resources.Load<Sprite>(path);
    }

    /// <summary>
    /// CSV 1행 파싱
    /// </summary>
    public static CharacterData ParseCSVLine(string line)
    {
        string[] cols = line.Split(',');
        if (cols.Length < 10) return null;

        CharacterData d = new CharacterData();
        d.charName = cols[0].Trim();
        float.TryParse(cols[1].Trim(), out d.charBaseSpeed);
        float.TryParse(cols[2].Trim(), out d.charBasePower);
        float.TryParse(cols[3].Trim(), out d.charBaseBrave);
        float.TryParse(cols[4].Trim(), out d.charBaseCalm);
        float.TryParse(cols[5].Trim(), out d.charBaseEndurance);
        d.charType = ParseType(cols[6].Trim());
        d.charAbility = cols[7].Trim();
        d.charResourcePrefabs = cols[8].Trim();
        d.charIcon = cols[9].Trim();
        return d;
    }

    private static CharacterType ParseType(string s)
    {
        switch (s.ToLower())
        {
            case "runner":   return CharacterType.Runner;
            case "leader":   return CharacterType.Leader;
            case "chaser":   return CharacterType.Chaser;
            case "reckoner": return CharacterType.Reckoner;
            default:
                Debug.LogWarning("[CharacterData] 알 수 없는 타입: " + s + " → Runner로 설정");
                return CharacterType.Runner;
        }
    }

    public string GetTypeName()
    {
        switch (charType)
        {
            case CharacterType.Runner:   return "도주";
            case CharacterType.Leader:   return "선행";
            case CharacterType.Chaser:   return "선입";
            case CharacterType.Reckoner: return "추입";
            default: return "???";
        }
    }

    public Color GetTypeColor()
    {
        switch (charType)
        {
            case CharacterType.Runner:   return new Color(1f, 0.4f, 0.4f);   // 빨강
            case CharacterType.Leader:   return new Color(0.4f, 0.7f, 1f);   // 파랑
            case CharacterType.Chaser:   return new Color(0.4f, 0.9f, 0.4f); // 초록
            case CharacterType.Reckoner: return new Color(1f, 0.8f, 0.3f);   // 노랑
            default: return Color.white;
        }
    }
}
