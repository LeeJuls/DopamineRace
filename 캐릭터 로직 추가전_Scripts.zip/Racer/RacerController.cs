using UnityEngine;
using System;
using System.Collections.Generic;

public class RacerController : MonoBehaviour
{
    private int racerIndex;
    private float currentSpeed = 0f;
    private float targetSpeed = 0f;
    private int currentWP = 0;
    private int currentLap = 0;
    private bool isRacing = false;
    private bool isFinished = false;
    private bool headingToFinish = false;
    private List<Transform> waypoints;
    private float speedTimer;
    private float laneOffset;
    private Animator animator;
    private Vector3 lastPosition;

    // ── 경로 이탈(흔들림) ──
    private float deviationOffset = 0f;
    private float deviationTarget = 0f;
    private float deviationTimer = 0f;

    public int RacerIndex => racerIndex;
    public bool IsFinished => isFinished;
    public int FinishOrder { get; set; } = -1;
    public float CurrentSpeed => currentSpeed;
    public int CurrentLap => currentLap;              // ★ STEP1: 현재 바퀴 수 외부 공개
    public float TotalProgress => isFinished ? float.MaxValue :
        (waypoints == null || waypoints.Count == 0) ? 0 :
        currentLap + (float)currentWP / waypoints.Count;

    // ★ STEP2: 이번 레이스 총 바퀴 수 (RaceManager에서 가져옴)
    private int GetTotalLaps()
    {
        return RaceManager.Instance != null ? RaceManager.Instance.CurrentLaps : GameConstants.TOTAL_LAPS;
    }

    public event Action<RacerController> OnFinished;

    public void Initialize(int index, List<Transform> wps)
    {
        racerIndex = index;
        waypoints = wps;
        laneOffset = (index - GameConstants.RACER_COUNT / 2f) * GameSettings.Instance.laneOffset;
        animator = GetComponentInChildren<Animator>();
    }

    /// <summary>
    /// 스폰 위치 확정 후 반드시 호출! (위치 세팅 이후에 호출해야 lastPosition이 정확함)
    /// </summary>
    public void ConfirmSpawnPosition()
    {
        lastPosition = transform.position;
        Debug.Log("[Racer " + racerIndex + "] 스폰 확정: " + transform.position);
    }

    public void StartRacing()
    {
        isRacing = true; isFinished = false; headingToFinish = false; FinishOrder = -1;
        currentLap = 0; speedTimer = 0f;
        targetSpeed = UnityEngine.Random.Range(GameConstants.RACER_MIN_SPEED, GameConstants.RACER_MAX_SPEED);
        currentSpeed = targetSpeed * 0.5f;

        // ★ 핵심: WP0(출발선)으로 먼저 이동 → 이후 WP1, 2, 3... 순서대로
        currentWP = 0;
        lastPosition = transform.position;

        // 흔들림 초기화
        deviationOffset = 0f;
        deviationTarget = 0f;
        deviationTimer = 0f;

        if (animator != null)
            animator.SetTrigger("Run");

        Debug.Log("[Racer " + racerIndex + "] 레이스 시작! " + GetTotalLaps() + "바퀴");
    }

    public void ResetRacer(Vector3 pos)
    {
        isRacing = false; isFinished = false; headingToFinish = false; FinishOrder = -1;
        currentSpeed = 0f; targetSpeed = 0f; currentWP = 0; currentLap = 0;
        deviationOffset = 0f;
        transform.position = pos;
        lastPosition = pos;

        if (animator != null)
            animator.SetTrigger("Idle");
    }

    private void Update()
    {
        ApplyLiveSettings();

        if (!isRacing || isFinished) return;
        if (waypoints == null || waypoints.Count == 0) return;

        // ── 속도 변경 ──
        speedTimer -= Time.deltaTime;
        if (speedTimer <= 0f)
        {
            targetSpeed = UnityEngine.Random.Range(GameConstants.RACER_MIN_SPEED, GameConstants.RACER_MAX_SPEED);
            speedTimer = GameConstants.SPEED_CHANGE_INTERVAL;
        }
        currentSpeed = Mathf.Lerp(currentSpeed, targetSpeed, Time.deltaTime * GameConstants.SPEED_LERP_RATE);

        // 경로 이탈 업데이트
        UpdateDeviation();

        // ── 이동: 항상 현재 목표 웨이포인트를 향해 직선 이동 ──
        Vector3 target = headingToFinish ? GetOffsetPosition(0) : GetOffsetPosition(currentWP);
        Vector3 dir = target - transform.position;
        float dist = dir.magnitude;

        if (dist < 0.25f)
        {
            if (headingToFinish)
            {
                // 결승선 도착!
                transform.position = target;
                isFinished = true; isRacing = false; currentSpeed = 0f;
                if (animator != null) animator.SetTrigger("Idle");
                OnFinished?.Invoke(this);
                return;
            }

            // 다음 웨이포인트로 전진
            currentWP++;
            if (currentWP >= waypoints.Count)
            {
                currentWP = 0;
                currentLap++;
                // ★ STEP2: RaceManager의 currentLaps 사용
                if (currentLap >= GetTotalLaps())
                {
                    headingToFinish = true;
                }
            }
        }
        else
        {
            float step = currentSpeed * Time.deltaTime;
            transform.position += dir.normalized * Mathf.Min(step, dist);
        }

        FlipSprite();
    }

    // 경로 좌우 흔들림
    private void UpdateDeviation()
    {
        float weight = GameSettings.Instance.pathDeviation;
        if (weight <= 0f)
        {
            deviationOffset = 0f;
            return;
        }

        deviationTimer -= Time.deltaTime;
        if (deviationTimer <= 0f)
        {
            deviationTarget = UnityEngine.Random.Range(-weight, weight);
            deviationTimer = UnityEngine.Random.Range(0.3f, 1.0f);
        }
        deviationOffset = Mathf.Lerp(deviationOffset, deviationTarget, Time.deltaTime * 3f);
    }

    private void FlipSprite()
    {
        Vector3 movement = transform.position - lastPosition;
        if (Mathf.Abs(movement.x) > 0.001f)
        {
            float scaleX = Mathf.Abs(transform.localScale.x);
            transform.localScale = new Vector3(
                movement.x < 0 ? scaleX : -scaleX,
                transform.localScale.y,
                transform.localScale.z
            );

            // 라벨/마커 항상 정방향 유지
            float parentSign = Mathf.Sign(transform.localScale.x);
            foreach (Transform child in transform)
            {
                if (child.GetComponent<TextMesh>() != null)
                {
                    Vector3 ls = child.localScale;
                    ls.x = Mathf.Abs(ls.x) * parentSign;
                    child.localScale = ls;
                }
            }
        }
        lastPosition = transform.position;
    }

    private void ApplyLiveSettings()
    {
        var s = GameSettings.Instance;
        float absScale = Mathf.Abs(s.characterScale);
        float sign = transform.localScale.x >= 0 ? 1f : -1f;
        transform.localScale = new Vector3(sign * absScale, absScale, 1f);

        laneOffset = (racerIndex - GameConstants.RACER_COUNT / 2f) * s.laneOffset;

        Transform lb = transform.Find("RaceLabel");
        if (lb != null)
        {
            lb.localPosition = new Vector3(0, s.labelHeight, 0);
            TextMesh tm = lb.GetComponent<TextMesh>();
            if (tm != null) tm.characterSize = s.labelSize;
        }
    }

    private Vector3 GetOffsetPosition(int wpIndex)
    {
        Vector3 wpPos = waypoints[wpIndex].position;
        Vector3 trackCenter = RaceManager.TrackCenter;
        Vector3 outward = (wpPos - trackCenter).normalized;
        return wpPos + outward * (laneOffset + deviationOffset);
    }
}