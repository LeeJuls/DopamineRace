using UnityEngine;

public class TrackVisualizer : MonoBehaviour
{
    private void Start()
    {
        LoadBackground();
    }

    private void LoadBackground()
    {
        Texture2D tex = Resources.Load<Texture2D>("ground_bg");
        if (tex == null)
        {
            Debug.LogError("ground_bg 이미지를 찾을 수 없습니다!");
            return;
        }
        tex.filterMode = FilterMode.Point;

        GameObject bg = new GameObject("BG_Track");
        bg.transform.SetParent(transform);
        SpriteRenderer sr = bg.AddComponent<SpriteRenderer>();
        sr.sprite = Sprite.Create(tex,
            new Rect(0, 0, tex.width, tex.height),
            new Vector2(0.5f, 0.5f), 70f);
        sr.sortingOrder = -100;
        bg.transform.position = new Vector3(2.5f, 0f, 0f);
    }
}